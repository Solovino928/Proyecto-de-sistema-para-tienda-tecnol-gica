-- ============================================================================
-- STOCKFLOW POS · SCRIPT CONSOLIDADO DE BASE DE DATOS (STKD_DBD_V3_1_051126)
-- Motor: PostgreSQL 16 (Docker)
-- Cumple con: STKD_DBD_V3_0_291026 y STKD_SRS_V0_3_291026 (MOD-01 a MOD-06)
-- ============================================================================

-- 1. Tabla del único vendedor (RN-11, RF-05.1, RF-05.2)
CREATE TABLE IF NOT EXISTS vendedor (
  id_vendedor        INT PRIMARY KEY CHECK (id_vendedor = 1),
  nombre             VARCHAR(50) NOT NULL,
  apellido           VARCHAR(50) NOT NULL,
  edad               INT NOT NULL CHECK (edad BETWEEN 18 AND 120),
  fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabla de categorías de producto (RN-15, RF-06.4 a RF-06.6)
CREATE TABLE IF NOT EXISTS categoria (
  id_categoria SERIAL PRIMARY KEY,
  nombre       VARCHAR(50) NOT NULL UNIQUE
);

-- 3. Tabla de productos (RN-02, RN-14, RN-16, RN-17, RF-01.1, RF-06.1 a RF-06.3)
CREATE TABLE IF NOT EXISTS producto (
  codigo       VARCHAR(10) PRIMARY KEY CHECK (codigo = UPPER(codigo)),
  id_categoria INT NOT NULL REFERENCES categoria(id_categoria) ON DELETE RESTRICT,
  nombre       VARCHAR(100) NOT NULL,
  precio       DECIMAL(10,2) NOT NULL CHECK (precio > 0),
  stock        INT NOT NULL DEFAULT 0 CHECK (stock >= 0)
);

-- 4. Secuencia y tabla de clientes (RF-04.1 a RF-04.10, RN-08, RN-09, RN-10)
CREATE SEQUENCE IF NOT EXISTS seq_cliente START 6;

CREATE TABLE IF NOT EXISTS cliente (
  codigo             VARCHAR(10) PRIMARY KEY,
  nombre             VARCHAR(50) NOT NULL,
  apellido           VARCHAR(50) NOT NULL,
  edad               INT CHECK (edad BETWEEN 18 AND 120),
  telefono           VARCHAR(10) NOT NULL CHECK (telefono ~ '^[0-9]{10}$'),
  correo             VARCHAR(100) UNIQUE,
  rfc                VARCHAR(13) UNIQUE,
  razon_social       VARCHAR(150),
  tipo               VARCHAR(10) NOT NULL CHECK (tipo IN ('FISICA','MORAL')),
  estado             VARCHAR(10) NOT NULL DEFAULT 'ACTIVO'
                     CHECK (estado IN ('ACTIVO','INACTIVO')),
  fecha_registro     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_modificacion TIMESTAMP,
  CHECK (rfc IS NULL OR (tipo = 'FISICA' AND LENGTH(rfc) = 13)
                     OR (tipo = 'MORAL'  AND LENGTH(rfc) = 12))
);

CREATE INDEX IF NOT EXISTS idx_cliente_nombre   ON cliente (apellido, nombre);
CREATE INDEX IF NOT EXISTS idx_cliente_telefono ON cliente (telefono);
CREATE INDEX IF NOT EXISTS idx_cliente_filtro   ON cliente (estado, tipo);

-- 5. Secuencia y tabla de órdenes de venta (RF-03.1 a RF-03.3, RN-05, RN-07, RN-10, RN-12)
CREATE SEQUENCE IF NOT EXISTS seq_folio START 1;

CREATE TABLE IF NOT EXISTS orden (
  folio            VARCHAR(20) PRIMARY KEY,
  id_vendedor      INT NOT NULL REFERENCES vendedor(id_vendedor),
  codigo_cliente   VARCHAR(10) REFERENCES cliente(codigo) ON DELETE RESTRICT,
  requiere_factura BOOLEAN NOT NULL DEFAULT FALSE,
  fecha_hora       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  subtotal         DECIMAL(10,2) NOT NULL,
  iva              DECIMAL(10,2) NOT NULL,
  total            DECIMAL(10,2) NOT NULL,
  CHECK (NOT requiere_factura OR codigo_cliente IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_orden_cliente ON orden (codigo_cliente, fecha_hora DESC);

-- 6. Tabla de detalle de órdenes (RN-01, RN-03, RN-16, RN-19)
CREATE TABLE IF NOT EXISTS detalle_orden (
  id_detalle      SERIAL PRIMARY KEY,
  folio_orden     VARCHAR(20) REFERENCES orden(folio),
  codigo_producto VARCHAR(10) REFERENCES producto(codigo) ON DELETE RESTRICT,
  cantidad        INT NOT NULL CHECK (cantidad > 0),
  precio_unitario DECIMAL(10,2) NOT NULL
);

-- 7. Tabla de movimientos de inventario (RF-06.7, RF-06.8, RN-18)
CREATE TABLE IF NOT EXISTS movimiento_inventario (
  id_movimiento       SERIAL PRIMARY KEY,
  codigo_producto     VARCHAR(10) NOT NULL REFERENCES producto(codigo) ON DELETE CASCADE,
  id_vendedor         INT NOT NULL REFERENCES vendedor(id_vendedor),
  tipo                VARCHAR(10) NOT NULL CHECK (tipo IN ('ENTRADA','AJUSTE')),
  cantidad            INT NOT NULL,
  existencia_anterior INT NOT NULL CHECK (existencia_anterior >= 0),
  existencia_nueva    INT NOT NULL CHECK (existencia_nueva >= 0),
  motivo              VARCHAR(150),
  fecha_hora          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (tipo = 'ENTRADA' OR (motivo IS NOT NULL AND LENGTH(TRIM(motivo)) > 0))
);

CREATE INDEX IF NOT EXISTS idx_mov_producto ON movimiento_inventario (codigo_producto, fecha_hora DESC);

-- ============================================================================
-- DATOS INICIALES OFICIALES (02_datos_iniciales.sql)
-- ============================================================================
INSERT INTO vendedor (id_vendedor, nombre, apellido, edad)
VALUES (1, 'Laura', 'Mendoza Cruz', 28)
ON CONFLICT (id_vendedor) DO NOTHING;

INSERT INTO categoria (id_categoria, nombre) VALUES
  (1, 'Perifericos'),
  (2, 'Almacenamiento'),
  (3, 'Accesorios y conectividad')
ON CONFLICT (nombre) DO NOTHING;

SELECT setval('categoria_id_categoria_seq', 3, true);

INSERT INTO producto (codigo, id_categoria, nombre, precio, stock) VALUES
  ('PER-001', 1, 'Teclado mecánico RGB', 850.00, 12),
  ('PER-003', 1, 'Mouse inalámbrico', 250.00, 20),
  ('PER-007', 1, 'Cámara web Full HD', 720.00, 6),
  ('ALM-002', 2, 'Memoria USB 64 GB', 180.00, 25),
  ('ALM-007', 2, 'SSD SATA 480 GB', 690.00, 8),
  ('ALM-009', 2, 'Disco duro externo 1 TB', 1250.00, 5),
  ('ACC-001', 3, 'Cable HDMI 2 metros', 150.00, 20),
  ('ACC-003', 3, 'Adaptador USB-C a HDMI', 350.00, 12),
  ('ACC-004', 3, 'Hub USB de 4 puertos', 290.00, 10),
  ('ACC-010', 3, 'Soporte ajustable para laptop', 320.00, 0)
ON CONFLICT (codigo) DO NOTHING;

INSERT INTO cliente (codigo, nombre, apellido, edad, telefono, correo, rfc, razon_social, tipo, estado) VALUES
  ('CLI-0001', 'Mariana', 'López Reyes', 33, '2725550142', 'mariana.lopez@correo.com', 'LORM9203154T3', 'Mariana López Reyes', 'FISICA', 'ACTIVO'),
  ('CLI-0002', 'Servicios Tecnológicos', 'del Valle', 30, '2725550199', 'compras@stvalle.mx', 'STV140612AB9', 'Servicios Tecnológicos del Valle SA de CV', 'MORAL', 'ACTIVO'),
  ('CLI-0003', 'Carlos', 'Hernández Ruiz', 29, '2725550177', NULL, NULL, NULL, 'FISICA', 'ACTIVO'),
  ('CLI-0004', 'Diana', 'Morales Soto', 37, '2725550123', 'diana.morales@correo.com', 'MOSD880920KP1', 'Diana Morales Soto', 'FISICA', 'INACTIVO'),
  ('CLI-0005', 'Taller Digital', 'Orizaba', 40, '2725550166', 'contacto@tallerdigital.mx', 'TDO190305QX2', 'Taller Digital Orizaba SA de CV', 'MORAL', 'ACTIVO')
ON CONFLICT (codigo) DO NOTHING;
