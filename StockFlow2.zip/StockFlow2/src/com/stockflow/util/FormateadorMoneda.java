package com.stockflow.util;

import java.text.DecimalFormat;

public class FormateadorMoneda {
    private static final DecimalFormat FORMATO = new DecimalFormat("$#,##0.00");

    public static String formatear(double monto) {
        return FORMATO.format(monto);
    }

    public static String formatearMXN(double monto) {
        return FORMATO.format(monto) + " MXN";
    }
}
