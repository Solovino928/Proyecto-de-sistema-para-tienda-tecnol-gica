package com.stockflow.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Gestiona la conexión JDBC hacia la base de datos local PostgreSQL en Docker.
 * Detecta automáticamente la contraseña configurada en el contenedor local.
 */
public class ConexionBD {
    private static final String HOST = System.getenv().getOrDefault("STKD_DB_HOST", "localhost");
    private static final String PORT = System.getenv().getOrDefault("STKD_DB_PORT", "5432");
    private static final String DB   = System.getenv().getOrDefault("STKD_DB_NAME", "stockflow");
    private static final String USER = System.getenv().getOrDefault("STKD_DB_USER", "postgres");

    private static final String[] POSIBLES_PASSWORDS = {
        System.getenv().getOrDefault("STKD_DB_PASS", "stockflow2026"),
        "postgres",
        "stockflow",
        "admin",
        "1234",
        ""
    };

    private static final String URL = "jdbc:postgresql://" + HOST + ":" + PORT + "/" + DB;
    private static String passwordActiva = null;
    private static boolean avisoImpreso = false;

    public static Connection obtenerConexion() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            if (!avisoImpreso) {
                System.err.println("[AVISO IMPORTANTE] Falta agregar el archivo postgresql-42.7.x.jar en la carpeta Libraries de NetBeans.");
                avisoImpreso = true;
            }
            throw new SQLException("Driver JDBC de PostgreSQL no encontrado.", e);
        }

        if (passwordActiva != null) {
            return DriverManager.getConnection(URL, USER, passwordActiva);
        }

        SQLException ultimoError = null;
        for (String pass : POSIBLES_PASSWORDS) {
            try {
                Connection conn = DriverManager.getConnection(URL, USER, pass);
                passwordActiva = pass;
                if (!avisoImpreso) {
                    System.out.println("[PostgreSQL Conectado] Leyendo y guardando datos en tiempo real desde " + URL);
                    avisoImpreso = true;
                }
                return conn;
            } catch (SQLException ex) {
                ultimoError = ex;
            }
        }
        throw ultimoError != null ? ultimoError : new SQLException("No se pudo conectar a PostgreSQL.");
    }

    public static boolean probarConexion() {
        try (Connection conn = obtenerConexion()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}
