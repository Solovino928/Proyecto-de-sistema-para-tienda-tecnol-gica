package com.stockflow.vista;

import com.stockflow.controlador.*;
import com.stockflow.modelo.*;
import com.stockflow.util.FormateadorMoneda;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana principal compatible con el diseñador visual (Design) de Apache NetBeans.
 * Incluye las pestañas visuales para Ventas (SCR-01), Clientes (SCR-04),
 * Inventario (SCR-08) y Vendedor (SCR-07).
 */
public class FrameVista extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrameVista.class.getName());

    private final CatalogoService catalogoService = new CatalogoService();
    private final VentaService ventaService = new VentaService();
    private final ClienteService clienteService = new ClienteService();
    private final VendedorService vendedorService = new VendedorService();
    private final ProductoService productoService = new ProductoService();
    private final CategoriaService categoriaService = new CategoriaService();
    private final InventarioService inventarioService = new InventarioService();

    private DefaultTableModel modeloCatalogo;
    private DefaultTableModel modeloVenta;
    private DefaultTableModel modeloClientes;
    private DefaultTableModel modeloInventario;
    private final ArrayList<Cliente> listaClientesCombo = new ArrayList<>();

    public FrameVista() {
        initComponents();
        configurarTablasYControles();
        recargarTodo();
        configurarAtajosTeclado();
    }

    private void configurarTablasYControles() {
        setLocationRelativeTo(null);
        btn_Confirmar.setEnabled(false);
        Spi_cantidad.setModel(new SpinnerNumberModel(1, 1, 999, 1));
        spnEdadVendedor.setModel(new SpinnerNumberModel(28, 18, 120, 1));

        modeloCatalogo = new DefaultTableModel(
                new Object[]{"Código", "Producto", "Categoría", "Precio (MXN)", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tbl_productos.setModel(modeloCatalogo);

        modeloVenta = new DefaultTableModel(
                new Object[]{"Código", "Producto", "Cant.", "P. Unitario", "Importe"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tbl_lista.setModel(modeloVenta);

        modeloClientes = new DefaultTableModel(
                new Object[]{"Código", "Nombre / Razón Social", "Tipo", "Teléfono", "RFC", "Estado", "Última modificación"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblClientes.setModel(modeloClientes);

        modeloInventario = new DefaultTableModel(
                new Object[]{"Código", "Producto", "Categoría", "Precio (sin IVA)", "Existencia"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblInventario.setModel(modeloInventario);

        // Refresca automáticamente los datos al cambiar entre las pestañas superiores
        tabbedVistas.addChangeListener(e -> recargarTodo());

        tbl_productos.getSelectionModel().addListSelectionListener(e -> validarCantidadEnTiempoReal());
        Spi_cantidad.addChangeListener(e -> validarCantidadEnTiempoReal());

        txtBusqueda.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrarCatalogo(); }
            public void removeUpdate(DocumentEvent e) { filtrarCatalogo(); }
            public void changedUpdate(DocumentEvent e) { filtrarCatalogo(); }
        });

        txtBusquedaCliente.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrarTablaClientes(); }
            public void removeUpdate(DocumentEvent e) { filtrarTablaClientes(); }
            public void changedUpdate(DocumentEvent e) { filtrarTablaClientes(); }
        });

        txtBusquedaInv.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrarTablaInventario(); }
            public void removeUpdate(DocumentEvent e) { filtrarTablaInventario(); }
            public void changedUpdate(DocumentEvent e) { filtrarTablaInventario(); }
        });
    }

    private void recargarTodo() {
        Vendedor vend = vendedorService.obtenerVendedor();
        lblVendedorHeader.setText("Vendedor: " + vend.nombreCompleto());

        String selCatVentas = (CBcategoria.getSelectedItem() != null) ? CBcategoria.getSelectedItem().toString() : "Todas";
        String selCatInv = (cmbCategoriaInv.getSelectedItem() != null) ? cmbCategoriaInv.getSelectedItem().toString() : "Todas";

        CBcategoria.removeAllItems();
        cmbCategoriaInv.removeAllItems();
        CBcategoria.addItem("Todas");
        cmbCategoriaInv.addItem("Todas");
        for (Categoria c : categoriaService.listar()) {
            CBcategoria.addItem(c.getNombre());
            cmbCategoriaInv.addItem(c.getNombre());
        }
        CBcategoria.setSelectedItem(selCatVentas);
        cmbCategoriaInv.setSelectedItem(selCatInv);

        cmbCliente.removeAllItems();
        listaClientesCombo.clear();
        cmbCliente.addItem("Público en general");
        for (Cliente c : clienteService.listarActivos()) {
            listaClientesCombo.add(c);
            cmbCliente.addItem(c.getNombreCompleto() + " (" + c.getIdentificador() + ")");
        }

        filtrarCatalogo();
        actualizarTablaVenta();
        filtrarTablaClientes();
        filtrarTablaInventario();
        cargarDatosVendedorEnPanel();
    }

    private void filtrarCatalogo() {
        if (modeloCatalogo == null) return;
        String texto = txtBusqueda != null ? txtBusqueda.getText() : "";
        String categoria = (CBcategoria != null && CBcategoria.getSelectedItem() != null)
                ? CBcategoria.getSelectedItem().toString() : "Todas";

        modeloCatalogo.setRowCount(0);
        for (Producto p : catalogoService.buscar(texto, categoria)) {
            modeloCatalogo.addRow(new Object[]{
                p.getIdentificador(),
                p.getNombre(),
                p.getCategoria().getNombre(),
                FormateadorMoneda.formatear(p.getPrecio()),
                p.getStock()
            });
        }
        validarCantidadEnTiempoReal();
    }

    private void validarCantidadEnTiempoReal() {
        int fila = tbl_productos.getSelectedRow();
        if (fila < 0) {
            lblAlertaStock.setText(" ");
            btn_Agregarventa.setEnabled(true);
            return;
        }
        String codigo = modeloCatalogo.getValueAt(fila, 0).toString();
        Producto p = catalogoService.buscarCodigo(codigo);
        int cant = (Integer) Spi_cantidad.getValue();

        int enCarrito = 0;
        for (DetalleVenta d : ventaService.getCarrito()) {
            if (d.getProducto().getIdentificador().equals(codigo)) {
                enCarrito = d.getCantidad();
                break;
            }
        }

        if (p != null && (cant + enCarrito) > p.getStock()) {
            lblAlertaStock.setText("EX-01: Stock insuficiente. Disponible: " + p.getStock());
            btn_Agregarventa.setEnabled(false);
        } else {
            lblAlertaStock.setText(" ");
            btn_Agregarventa.setEnabled(true);
        }
    }

    private void actualizarTablaVenta() {
        if (modeloVenta == null) return;
        modeloVenta.setRowCount(0);
        for (DetalleVenta d : ventaService.getCarrito()) {
            modeloVenta.addRow(new Object[]{
                d.getProducto().getIdentificador(),
                d.getProducto().getNombre(),
                d.getCantidad(),
                FormateadorMoneda.formatear(d.getPrecioUnitario()),
                FormateadorMoneda.formatear(d.calcularImporte())
            });
        }

        lbl_Subtotal.setText(FormateadorMoneda.formatear(ventaService.obtenerSubtotal()));
        lbl_IVA.setText(FormateadorMoneda.formatear(ventaService.obtenerIVA()));
        lbl_Total.setText(FormateadorMoneda.formatearMXN(ventaService.obtenerTotal()));
        btn_Confirmar.setEnabled(!ventaService.getCarrito().isEmpty());
    }

    private void filtrarTablaClientes() {
        if (modeloClientes == null) return;
        String texto = txtBusquedaCliente != null ? txtBusquedaCliente.getText() : "";
        String est = (cmbEstadoCliente != null && cmbEstadoCliente.getSelectedItem() != null)
                ? cmbEstadoCliente.getSelectedItem().toString() : "Todos";
        String tip = (cmbTipoClienteFiltro != null && cmbTipoClienteFiltro.getSelectedItem() != null)
                ? cmbTipoClienteFiltro.getSelectedItem().toString() : "Todos";

        modeloClientes.setRowCount(0);
        for (Cliente c : clienteService.buscarYFiltrar(texto, est, tip)) {
            modeloClientes.addRow(new Object[]{
                c.getIdentificador(),
                c.getNombreORazonSocial(),
                c.getTipo().getEtiqueta(),
                c.getTelefono(),
                c.getRfc() != null ? c.getRfc() : "—",
                c.getEstado().getEtiqueta(),
                c.getFechaModificacionFormateada()
            });
        }
    }

    private void filtrarTablaInventario() {
        if (modeloInventario == null) return;
        String texto = txtBusquedaInv != null ? txtBusquedaInv.getText() : "";
        String cat = (cmbCategoriaInv != null && cmbCategoriaInv.getSelectedItem() != null)
                ? cmbCategoriaInv.getSelectedItem().toString() : "Todas";

        modeloInventario.setRowCount(0);
        for (Producto p : catalogoService.buscar(texto, cat)) {
            modeloInventario.addRow(new Object[]{
                p.getIdentificador(),
                p.getNombre(),
                p.getCategoria().getNombre(),
                FormateadorMoneda.formatear(p.getPrecio()),
                p.getStock() == 0 ? "0 · Agotado" : p.getStock()
            });
        }
    }

    private void cargarDatosVendedorEnPanel() {
        Vendedor v = vendedorService.obtenerVendedor();
        txtNombreVendedor.setText(v.getNombre());
        txtApellidoVendedor.setText(v.getApellido());
        spnEdadVendedor.setValue(v.getEdad());
        lblFechaModVendedor.setText(v.getFechaModificacionFormateada());
        lblVentasVendedor.setText(String.valueOf(vendedorService.contarVentasRegistradas()));
    }

    private Cliente obtenerClienteSeleccionado() {
        int fila = tblClientes.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente en la tabla.");
            return null;
        }
        String codigo = modeloClientes.getValueAt(fila, 0).toString();
        return clienteService.buscarPorCodigo(codigo);
    }

    private Producto obtenerProductoInventarioSeleccionado() {
        int fila = tblInventario.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto en la tabla de inventario.");
            return null;
        }
        String codigo = modeloInventario.getValueAt(fila, 0).toString();
        return catalogoService.buscarCodigo(codigo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        lblVendedorHeader = new javax.swing.JLabel();
        tabbedVistas = new javax.swing.JTabbedPane();
        pnlVentas = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_productos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        CBcategoria = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        Spi_cantidad = new javax.swing.JSpinner();
        btn_Agregarventa = new javax.swing.JButton();
        lblAlertaStock = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cmbCliente = new javax.swing.JComboBox<>();
        btnNuevoClienteRapido = new javax.swing.JButton();
        chkFactura = new javax.swing.JCheckBox();
        btn_Quitar = new javax.swing.JButton();
        btn_Limpiar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_lista = new javax.swing.JTable();
        btn_Confirmar = new javax.swing.JToggleButton();
        jLabel7 = new javax.swing.JLabel();
        lbl_Subtotal = new javax.swing.JLabel();
        lbl_IVA = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lbl_Total = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        pnlClientes = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtBusquedaCliente = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cmbEstadoCliente = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cmbTipoClienteFiltro = new javax.swing.JComboBox<>();
        btnNuevoCliente = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        btnVerPerfil = new javax.swing.JButton();
        btnEditarCliente = new javax.swing.JButton();
        btnCambiarEstadoCliente = new javax.swing.JButton();
        btnEliminarCliente = new javax.swing.JButton();
        lblAvisoPrivacidad = new javax.swing.JLabel();
        pnlInventario = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        txtBusquedaInv = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        cmbCategoriaInv = new javax.swing.JComboBox<>();
        btnCategorias = new javax.swing.JButton();
        btnNuevoProducto = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblInventario = new javax.swing.JTable();
        btnModificarProducto = new javax.swing.JButton();
        btnAnadirStock = new javax.swing.JButton();
        btnAjustarStock = new javax.swing.JButton();
        btnHistorialMovs = new javax.swing.JButton();
        btnEliminarProducto = new javax.swing.JButton();
        pnlVendedor = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        txtNombreVendedor = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtApellidoVendedor = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        spnEdadVendedor = new javax.swing.JSpinner();
        jLabel19 = new javax.swing.JLabel();
        lblFechaModVendedor = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        lblVentasVendedor = new javax.swing.JLabel();
        btnCancelarVendedor = new javax.swing.JButton();
        btnGuardarVendedor = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("StockFlow POS - Sistema de Ventas de Escritorio");

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("StockFlow - Mostrador de ventas");

        lblVendedorHeader.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        lblVendedorHeader.setForeground(new java.awt.Color(255, 255, 255));
        lblVendedorHeader.setText("Vendedor: Laura Mendoza Cruz");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblVendedorHeader)
                .addGap(24, 24, 24))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lblVendedorHeader))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tbl_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "Código", "Producto", "Categoría", "Precio (MXN)", "Stock"
            }
        ));
        jScrollPane1.setViewportView(tbl_productos);

        jLabel1.setText("Buscar");

        txtBusqueda.addActionListener(this::txtBusquedaActionPerformed);

        CBcategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todas", "Perifericos", "Almacenamiento", "Accesorios y conectividad" }));
        CBcategoria.addActionListener(this::CBcategoriaActionPerformed);

        jLabel3.setText("Cantidad");

        btn_Agregarventa.setText("Agregar a la venta");
        btn_Agregarventa.addActionListener(this::btn_AgregarventaActionPerformed);

        lblAlertaStock.setForeground(new java.awt.Color(204, 0, 0));
        lblAlertaStock.setText(" ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAlertaStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(CBcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(Spi_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(btn_Agregarventa)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(24, 24, 24))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CBcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Spi_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Agregarventa))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblAlertaStock)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel10.setText("Cliente:");

        cmbCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Público en general" }));

        btnNuevoClienteRapido.setText("+ Nuevo");
        btnNuevoClienteRapido.addActionListener(this::btnNuevoClienteRapidoActionPerformed);

        chkFactura.setText("Requiere factura");

        btn_Quitar.setText("Quitar Artículo Seleccionado");
        btn_Quitar.addActionListener(this::btn_QuitarActionPerformed);

        btn_Limpiar.setText("Limpiar Lista");
        btn_Limpiar.addActionListener(this::btn_LimpiarActionPerformed);

        tbl_lista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "Código", "Producto", "Cant.", "P. Unitario", "Importe"
            }
        ));
        jScrollPane2.setViewportView(tbl_lista);

        btn_Confirmar.setText("Confirmar Venta (F5)");
        btn_Confirmar.addActionListener(this::btn_ConfirmarActionPerformed);

        jLabel7.setText("Subtotal");

        lbl_Subtotal.setText("$0.00");

        lbl_IVA.setText("$0.00");

        jLabel8.setText("IVA 16%");

        jLabel9.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel9.setText("Total");

        lbl_Total.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        lbl_Total.setText("$0.00 MXN");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbCliente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNuevoClienteRapido))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(chkFactura)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_Quitar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_Limpiar))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(48, 48, 48)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_Subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_IVA, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(lbl_Total, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_Confirmar)))))
                .addGap(24, 24, 24))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cmbCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNuevoClienteRapido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkFactura)
                    .addComponent(btn_Quitar)
                    .addComponent(btn_Limpiar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lbl_Subtotal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lbl_IVA))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(lbl_Total)
                    .addComponent(btn_Confirmar))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel5.setText("Catálogo de productos (MOD-01)");

        jLabel6.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel6.setText("Lista de la compra y registro (MOD-02 y MOD-03)");

        javax.swing.GroupLayout pnlVentasLayout = new javax.swing.GroupLayout(pnlVentas);
        pnlVentas.setLayout(pnlVentasLayout);
        pnlVentasLayout.setHorizontalGroup(
            pnlVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVentasLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(pnlVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        pnlVentasLayout.setVerticalGroup(
            pnlVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVentasLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(pnlVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        tabbedVistas.addTab("Ventas (SCR-01)", pnlVentas);

        jLabel11.setText("Buscar cliente:");

        jLabel12.setText("Estado:");

        cmbEstadoCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Activo", "Inactivo" }));
        cmbEstadoCliente.addActionListener(this::cmbEstadoClienteActionPerformed);

        jLabel13.setText("Tipo:");

        cmbTipoClienteFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Persona Física", "Persona Moral" }));
        cmbTipoClienteFiltro.addActionListener(this::cmbTipoClienteFiltroActionPerformed);

        btnNuevoCliente.setText("+ NUEVO CLIENTE (F6)");
        btnNuevoCliente.addActionListener(this::btnNuevoClienteActionPerformed);

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "Código", "Nombre / Razón Social", "Tipo", "Teléfono", "RFC", "Estado", "Última modificación"
            }
        ));
        jScrollPane3.setViewportView(tblClientes);

        btnVerPerfil.setText("VER PERFIL (Enter)");
        btnVerPerfil.addActionListener(this::btnVerPerfilActionPerformed);

        btnEditarCliente.setText("EDITAR (F4)");
        btnEditarCliente.addActionListener(this::btnEditarClienteActionPerformed);

        btnCambiarEstadoCliente.setText("CAMBIAR A INACTIVO / ACTIVO");
        btnCambiarEstadoCliente.addActionListener(this::btnCambiarEstadoClienteActionPerformed);

        btnEliminarCliente.setText("ELIMINAR (Supr)");
        btnEliminarCliente.addActionListener(this::btnEliminarClienteActionPerformed);

        lblAvisoPrivacidad.setText("RNF-09: Los datos personales se usan solo para facturación y atención de ventas y se almacenan únicamente en este equipo.");

        javax.swing.GroupLayout pnlClientesLayout = new javax.swing.GroupLayout(pnlClientes);
        pnlClientes.setLayout(pnlClientesLayout);
        pnlClientesLayout.setHorizontalGroup(
            pnlClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlClientesLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(pnlClientesLayout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBusquedaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbEstadoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbTipoClienteFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 180, Short.MAX_VALUE)
                        .addComponent(btnNuevoCliente))
                    .addGroup(pnlClientesLayout.createSequentialGroup()
                        .addComponent(btnVerPerfil)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditarCliente)
                        .addGap(18, 18, 18)
                        .addComponent(btnCambiarEstadoCliente)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminarCliente)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(lblAvisoPrivacidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        pnlClientesLayout.setVerticalGroup(
            pnlClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlClientesLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(pnlClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtBusquedaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(cmbEstadoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(cmbTipoClienteFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNuevoCliente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVerPerfil)
                    .addComponent(btnEditarCliente)
                    .addComponent(btnCambiarEstadoCliente)
                    .addComponent(btnEliminarCliente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblAvisoPrivacidad)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        tabbedVistas.addTab("Clientes (SCR-04)", pnlClientes);

        jLabel14.setText("Buscar producto:");

        jLabel15.setText("Categoría:");

        cmbCategoriaInv.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todas" }));
        cmbCategoriaInv.addActionListener(this::cmbCategoriaInvActionPerformed);

        btnCategorias.setText("CATEGORÍAS (F7)");
        btnCategorias.addActionListener(this::btnCategoriasActionPerformed);

        btnNuevoProducto.setText("+ NUEVO PRODUCTO (F6)");
        btnNuevoProducto.addActionListener(this::btnNuevoProductoActionPerformed);

        tblInventario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "Código", "Producto", "Categoría", "Precio (sin IVA)", "Existencia"
            }
        ));
        jScrollPane4.setViewportView(tblInventario);

        btnModificarProducto.setText("MODIFICAR (F4)");
        btnModificarProducto.addActionListener(this::btnModificarProductoActionPerformed);

        btnAnadirStock.setText("+ AÑADIR STOCK (F8)");
        btnAnadirStock.addActionListener(this::btnAnadirStockActionPerformed);

        btnAjustarStock.setText("AJUSTAR STOCK (F9)");
        btnAjustarStock.addActionListener(this::btnAjustarStockActionPerformed);

        btnHistorialMovs.setText("HISTORIAL MOVIMIENTOS");
        btnHistorialMovs.addActionListener(this::btnHistorialMovsActionPerformed);

        btnEliminarProducto.setText("ELIMINAR (Supr)");
        btnEliminarProducto.addActionListener(this::btnEliminarProductoActionPerformed);

        javax.swing.GroupLayout pnlInventarioLayout = new javax.swing.GroupLayout(pnlInventario);
        pnlInventario.setLayout(pnlInventarioLayout);
        pnlInventarioLayout.setHorizontalGroup(
            pnlInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlInventarioLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(pnlInventarioLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBusquedaInv, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbCategoriaInv, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 220, Short.MAX_VALUE)
                        .addComponent(btnCategorias)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNuevoProducto))
                    .addGroup(pnlInventarioLayout.createSequentialGroup()
                        .addComponent(btnModificarProducto)
                        .addGap(18, 18, 18)
                        .addComponent(btnAnadirStock)
                        .addGap(18, 18, 18)
                        .addComponent(btnAjustarStock)
                        .addGap(18, 18, 18)
                        .addComponent(btnHistorialMovs)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminarProducto)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(20, 20, 20))
        );
        pnlInventarioLayout.setVerticalGroup(
            pnlInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlInventarioLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(pnlInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtBusquedaInv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(cmbCategoriaInv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCategorias)
                    .addComponent(btnNuevoProducto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnModificarProducto)
                    .addComponent(btnAnadirStock)
                    .addComponent(btnAjustarStock)
                    .addComponent(btnHistorialMovs)
                    .addComponent(btnEliminarProducto))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        tabbedVistas.addTab("Inventario (SCR-08)", pnlInventario);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Perfil del único vendedor registrado (SCR-07 · RN-11)"));

        jLabel16.setText("Nombre *:");

        jLabel17.setText("Apellido *:");

        jLabel18.setText("Edad (18-120) *:");

        jLabel19.setText("Fecha de última modificación:");

        lblFechaModVendedor.setText("—");

        jLabel20.setText("Ventas registradas por este vendedor:");

        lblVentasVendedor.setText("0");

        btnCancelarVendedor.setText("CANCELAR");
        btnCancelarVendedor.addActionListener(this::btnCancelarVendedorActionPerformed);

        btnGuardarVendedor.setText("GUARDAR CAMBIOS (F5)");
        btnGuardarVendedor.addActionListener(this::btnGuardarVendedorActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(btnCancelarVendedor))
                .addGap(36, 36, 36)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtNombreVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                    .addComponent(txtApellidoVendedor)
                    .addComponent(spnEdadVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFechaModVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblVentasVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGuardarVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtNombreVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtApellidoVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(spnEdadVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(lblFechaModVendedor))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(lblVentasVendedor))
                .addGap(28, 28, 28)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelarVendedor)
                    .addComponent(btnGuardarVendedor))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlVendedorLayout = new javax.swing.GroupLayout(pnlVendedor);
        pnlVendedor.setLayout(pnlVendedorLayout);
        pnlVendedorLayout.setHorizontalGroup(
            pnlVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVendedorLayout.createSequentialGroup()
                .addGap(260, 260, 260)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(364, Short.MAX_VALUE))
        );
        pnlVendedorLayout.setVerticalGroup(
            pnlVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVendedorLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(140, Short.MAX_VALUE))
        );

        tabbedVistas.addTab("Vendedor (SCR-07)", pnlVendedor);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tabbedVistas)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabbedVistas))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBusquedaActionPerformed
        filtrarCatalogo();
    }//GEN-LAST:event_txtBusquedaActionPerformed

    private void CBcategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBcategoriaActionPerformed
        filtrarCatalogo();
    }//GEN-LAST:event_CBcategoriaActionPerformed

    private void btn_AgregarventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_AgregarventaActionPerformed
        int fila = tbl_productos.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto del catálogo.");
            return;
        }
        String codigo = modeloCatalogo.getValueAt(fila, 0).toString();
        Producto prod = catalogoService.buscarCodigo(codigo);
        int cantidad = (Integer) Spi_cantidad.getValue();

        String error = ventaService.agregarAlCarrito(prod, cantidad);
        if (error != null) {
            lblAlertaStock.setText(error);
            JOptionPane.showMessageDialog(this, error, "Alerta de Stock (EX-01)", JOptionPane.WARNING_MESSAGE);
        } else {
            Spi_cantidad.setValue(1);
            actualizarTablaVenta();
            validarCantidadEnTiempoReal();
        }
    }//GEN-LAST:event_btn_AgregarventaActionPerformed

    private void btnNuevoClienteRapidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoClienteRapidoActionPerformed
        abrirDialogoFormularioCliente(null);
    }//GEN-LAST:event_btnNuevoClienteRapidoActionPerformed

    private void btn_QuitarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QuitarActionPerformed
        int fila = tbl_lista.getSelectedRow();
        if (fila >= 0) {
            ventaService.quitarDelCarrito(fila);
            actualizarTablaVenta();
            validarCantidadEnTiempoReal();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un artículo de la lista para quitarlo.");
        }
    }//GEN-LAST:event_btn_QuitarActionPerformed

    private void btn_LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LimpiarActionPerformed
        ventaService.limpiarCarrito();
        actualizarTablaVenta();
        validarCantidadEnTiempoReal();
    }//GEN-LAST:event_btn_LimpiarActionPerformed

    private void btn_ConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ConfirmarActionPerformed
        if (ventaService.getCarrito().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La venta debe tener al menos una partida (RN-04).");
            return;
        }

        Cliente clienteElegido = null;
        int idxCombo = cmbCliente.getSelectedIndex();
        if (idxCombo > 0 && (idxCombo - 1) < listaClientesCombo.size()) {
            clienteElegido = listaClientesCombo.get(idxCombo - 1);
        }

        boolean requiereFac = chkFactura.isSelected();
        double subtotal = ventaService.obtenerSubtotal();
        double iva = ventaService.obtenerIVA();
        double total = ventaService.obtenerTotal();

        Venta nuevaVenta = new Venta(
                "PENDIENTE",
                ventaService.obtenerVendedor(),
                clienteElegido,
                requiereFac,
                ventaService.getCarrito(),
                subtotal,
                iva,
                total
        );

        String errorFactura = ventaService.validarFactura(nuevaVenta);
        if (errorFactura != null) {
            Object[] opciones = (clienteElegido != null)
                    ? new Object[]{"Abrir perfil del cliente", "Cancelar"}
                    : new Object[]{"Aceptar"};
            int r = JOptionPane.showOptionDialog(this, errorFactura, "Validación de Factura (EX-06)",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, opciones, opciones[0]);
            if (clienteElegido != null && r == 0) {
                abrirDialogoFormularioCliente(clienteElegido);
            }
            return;
        }

        String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        StringBuilder resumen = new StringBuilder();
        resumen.append("=== CONFIRMAR REGISTRO DE VENTA - STOCKFLOW (SCR-02) ===\n");
        resumen.append("Fecha y Hora: ").append(fechaHora).append("\n");
        resumen.append("Vendedor: ").append(nuevaVenta.getVendedor().nombreCompleto()).append("\n");
        resumen.append("Cliente: ").append(clienteElegido != null ? clienteElegido.mostrarResumen() : "Público en general").append("\n");
        resumen.append("Factura: ").append(requiereFac ? "Sí, requiere factura" : "No").append("\n");
        resumen.append("--------------------------------------------------\n");

        for (DetalleVenta d : nuevaVenta.getDetalles()) {
            resumen.append(d.getCantidad()).append("x ")
                   .append(d.getProducto().getNombre())
                   .append(" (").append(d.getProducto().getIdentificador()).append(")")
                   .append("  ->  ").append(FormateadorMoneda.formatear(d.calcularImporte())).append("\n");
        }

        resumen.append("--------------------------------------------------\n");
        resumen.append("Subtotal: ").append(FormateadorMoneda.formatearMXN(subtotal)).append("\n");
        resumen.append("IVA (16%): ").append(FormateadorMoneda.formatearMXN(iva)).append("\n");
        resumen.append("TOTAL A COBRAR: ").append(FormateadorMoneda.formatearMXN(total)).append("\n\n");
        resumen.append("¿Desea confirmar y registrar la venta?");

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                resumen.toString(),
                "Confirmar Registro de Venta (SCR-02)",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean exito = ventaService.procesarVenta(nuevaVenta);
            if (exito) {
                cmbCliente.setSelectedIndex(0);
                chkFactura.setSelected(false);
                recargarTodo();

                JOptionPane.showMessageDialog(
                        this,
                        "¡VENTA REGISTRADA CON ÉXITO!\n\n"
                        + "FOLIO ASIGNADO: " + nuevaVenta.getIdentificador() + "\n"
                        + "Vendedor: " + nuevaVenta.getVendedor().nombreCompleto() + "\n"
                        + "Cliente: " + (clienteElegido != null ? clienteElegido.mostrarResumen() : "Público en general") + "\n"
                        + "Total cobrado: " + FormateadorMoneda.formatearMXN(total) + "\n\n"
                        + "El inventario ha sido actualizado y la pantalla está lista para la siguiente venta.",
                        "Venta Exitosa - Folio " + nuevaVenta.getIdentificador() + " (SCR-03)",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "EX-03: Error al guardar la venta. No se restaron existencias.",
                        "Error de Transacción (EX-03)",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }//GEN-LAST:event_btn_ConfirmarActionPerformed

    private void cmbEstadoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbEstadoClienteActionPerformed
        filtrarTablaClientes();
    }//GEN-LAST:event_cmbEstadoClienteActionPerformed

    private void cmbTipoClienteFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoClienteFiltroActionPerformed
        filtrarTablaClientes();
    }//GEN-LAST:event_cmbTipoClienteFiltroActionPerformed

    private void btnNuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoClienteActionPerformed
        abrirDialogoFormularioCliente(null);
    }//GEN-LAST:event_btnNuevoClienteActionPerformed

    private void btnVerPerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerPerfilActionPerformed
        abrirPerfilClienteSCR06();
    }//GEN-LAST:event_btnVerPerfilActionPerformed

    private void btnEditarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarClienteActionPerformed
        Cliente sel = obtenerClienteSeleccionado();
        if (sel != null) abrirDialogoFormularioCliente(sel);
    }//GEN-LAST:event_btnEditarClienteActionPerformed

    private void btnCambiarEstadoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCambiarEstadoClienteActionPerformed
        Cliente sel = obtenerClienteSeleccionado();
        if (sel != null) {
            clienteService.cambiarEstado(sel.getIdentificador());
            recargarTodo();
        }
    }//GEN-LAST:event_btnCambiarEstadoClienteActionPerformed

    private void btnEliminarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarClienteActionPerformed
        accionEliminarClienteSCR12y13();
    }//GEN-LAST:event_btnEliminarClienteActionPerformed

    private void cmbCategoriaInvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoriaInvActionPerformed
        filtrarTablaInventario();
    }//GEN-LAST:event_cmbCategoriaInvActionPerformed

    private void btnCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoriasActionPerformed
        abrirDialogoCategoriasSCR10();
    }//GEN-LAST:event_btnCategoriasActionPerformed

    private void btnNuevoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoProductoActionPerformed
        abrirDialogoProductoSCR09(null);
    }//GEN-LAST:event_btnNuevoProductoActionPerformed

    private void btnModificarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarProductoActionPerformed
        Producto p = obtenerProductoInventarioSeleccionado();
        if (p != null) abrirDialogoProductoSCR09(p);
    }//GEN-LAST:event_btnModificarProductoActionPerformed

    private void btnAnadirStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnadirStockActionPerformed
        Producto p = obtenerProductoInventarioSeleccionado();
        if (p != null) abrirDialogoStockSCR11(p, true);
    }//GEN-LAST:event_btnAnadirStockActionPerformed

    private void btnAjustarStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAjustarStockActionPerformed
        Producto p = obtenerProductoInventarioSeleccionado();
        if (p != null) abrirDialogoStockSCR11(p, false);
    }//GEN-LAST:event_btnAjustarStockActionPerformed

    private void btnHistorialMovsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialMovsActionPerformed
        mostrarBitacoraMovimientos();
    }//GEN-LAST:event_btnHistorialMovsActionPerformed

    private void btnEliminarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProductoActionPerformed
        accionEliminarProducto();
    }//GEN-LAST:event_btnEliminarProductoActionPerformed

    private void btnCancelarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarVendedorActionPerformed
        cargarDatosVendedorEnPanel();
    }//GEN-LAST:event_btnCancelarVendedorActionPerformed

    private void btnGuardarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarVendedorActionPerformed
        String err = vendedorService.actualizar(
                txtNombreVendedor.getText(),
                txtApellidoVendedor.getText(),
                (Integer) spnEdadVendedor.getValue());
        if (err != null) {
            JOptionPane.showMessageDialog(this, err, "Validación de Vendedor (EX-04)", JOptionPane.WARNING_MESSAGE);
        } else {
            recargarTodo();
            JOptionPane.showMessageDialog(this,
                    "Perfil del vendedor actualizado correctamente (RF-05.1 y RF-05.2).",
                    "Perfil Actualizado", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnGuardarVendedorActionPerformed

    // Diálogos auxiliares de Clientes e Inventario (SCR-05, SCR-06, SCR-09, SCR-10, SCR-11, SCR-12, SCR-13)
    private void abrirDialogoFormularioCliente(Cliente clienteEditar) {
        boolean esEdicion = (clienteEditar != null);
        JDialog dlg = new JDialog(this, esEdicion
                ? "Editar Cliente · " + clienteEditar.getIdentificador() + " (SCR-05)"
                : "Nuevo Cliente · Código: " + clienteService.obtenerSiguienteCodigo() + " (autogenerado) (SCR-05)", true);
        dlg.setSize(580, 460);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel pnlForm = new JPanel(new GridLayout(8, 2, 8, 8));
        pnlForm.setBorder(new EmptyBorder(14, 16, 6, 16));

        JTextField txtNom = new JTextField(esEdicion ? clienteEditar.getNombre() : "");
        JTextField txtApe = new JTextField(esEdicion ? clienteEditar.getApellido() : "");
        JTextField txtEdad = new JTextField(esEdicion && clienteEditar.getEdad() != null ? String.valueOf(clienteEditar.getEdad()) : "30");
        JTextField txtTel = new JTextField(esEdicion ? clienteEditar.getTelefono() : "");
        JTextField txtCor = new JTextField(esEdicion && clienteEditar.getCorreo() != null ? clienteEditar.getCorreo() : "");
        JComboBox<TipoCliente> cmbTip = new JComboBox<>(TipoCliente.values());
        if (esEdicion) cmbTip.setSelectedItem(clienteEditar.getTipo());
        JTextField txtRfc = new JTextField(esEdicion && clienteEditar.getRfc() != null ? clienteEditar.getRfc() : "");
        JTextField txtRaz = new JTextField(esEdicion && clienteEditar.getRazonSocial() != null ? clienteEditar.getRazonSocial() : "");

        pnlForm.add(new JLabel("Nombre *:"));
        pnlForm.add(txtNom);
        pnlForm.add(new JLabel("Apellido *:"));
        pnlForm.add(txtApe);
        pnlForm.add(new JLabel("Edad (18–120):"));
        pnlForm.add(txtEdad);
        pnlForm.add(new JLabel("Teléfono * (10 dígitos):"));
        pnlForm.add(txtTel);
        pnlForm.add(new JLabel("Correo electrónico:"));
        pnlForm.add(txtCor);
        pnlForm.add(new JLabel("Tipo de cliente *:"));
        pnlForm.add(cmbTip);
        pnlForm.add(new JLabel("RFC (13 Física / 12 Moral):"));
        pnlForm.add(txtRfc);
        pnlForm.add(new JLabel("Razón social:"));
        pnlForm.add(txtRaz);

        JLabel lblAlertaModal = new JLabel(" ");
        lblAlertaModal.setForeground(new Color(204, 0, 0));
        lblAlertaModal.setBorder(new EmptyBorder(0, 16, 0, 16));

        JButton btnGuardar = new JButton("GUARDAR (F5)");
        Runnable validarDuplicadosEnVivo = () -> {
            String codActual = esEdicion ? clienteEditar.getIdentificador() : null;
            Cliente dupRfc = clienteService.buscarConflictoRfc(txtRfc.getText(), codActual);
            Cliente dupCor = clienteService.buscarConflictoCorreo(txtCor.getText(), codActual);
            if (dupRfc != null) {
                lblAlertaModal.setText("EX-05: Este RFC ya pertenece al cliente " + dupRfc.getIdentificador() + ".");
                btnGuardar.setEnabled(false);
            } else if (dupCor != null) {
                lblAlertaModal.setText("EX-05: Este correo ya pertenece al cliente " + dupCor.getIdentificador() + ".");
                btnGuardar.setEnabled(false);
            } else {
                lblAlertaModal.setText(" ");
                btnGuardar.setEnabled(true);
            }
        };

        DocumentListener dl = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { validarDuplicadosEnVivo.run(); }
            public void removeUpdate(DocumentEvent e) { validarDuplicadosEnVivo.run(); }
            public void changedUpdate(DocumentEvent e) { validarDuplicadosEnVivo.run(); }
        };
        txtRfc.getDocument().addDocumentListener(dl);
        txtCor.getDocument().addDocumentListener(dl);

        btnGuardar.addActionListener(e -> {
            Integer edadVal = null;
            if (!txtEdad.getText().trim().isEmpty()) {
                try {
                    edadVal = Integer.parseInt(txtEdad.getText().trim());
                } catch (NumberFormatException ex) {
                    lblAlertaModal.setText("EX-04: La edad debe ser un número entero entre 18 y 120.");
                    return;
                }
            }
            if (!esEdicion) {
                Cliente nuevo = new Cliente("TEMP", txtNom.getText().trim(), txtApe.getText().trim(),
                        edadVal, txtTel.getText().trim(), txtCor.getText().trim(),
                        txtRfc.getText().trim(), txtRaz.getText().trim(),
                        (TipoCliente) cmbTip.getSelectedItem());
                String err = clienteService.registrar(nuevo);
                if (err != null) {
                    lblAlertaModal.setText(err);
                } else {
                    recargarTodo();
                    dlg.dispose();
                }
            } else {
                Cliente temp = new Cliente(clienteEditar.getIdentificador(), txtNom.getText().trim(),
                        txtApe.getText().trim(), edadVal, txtTel.getText().trim(),
                        txtCor.getText().trim(), txtRfc.getText().trim(),
                        txtRaz.getText().trim(), (TipoCliente) cmbTip.getSelectedItem());
                String err = clienteService.actualizar(temp);
                if (err != null) {
                    lblAlertaModal.setText(err);
                } else {
                    clienteEditar.setNombre(temp.getNombre());
                    clienteEditar.setApellido(temp.getApellido());
                    clienteEditar.setEdad(temp.getEdad());
                    clienteEditar.setTelefono(temp.getTelefono());
                    clienteEditar.setCorreo(temp.getCorreo());
                    clienteEditar.setRfc(temp.getRfc());
                    clienteEditar.setRazonSocial(temp.getRazonSocial());
                    clienteEditar.setTipo(temp.getTipo());
                    recargarTodo();
                    dlg.dispose();
                }
            }
        });

        JButton btnCancelar = new JButton("ESC Cancelar");
        btnCancelar.addActionListener(e -> dlg.dispose());

        JPanel pnlSur = new JPanel(new BorderLayout(0, 6));
        pnlSur.setBorder(new EmptyBorder(4, 16, 14, 16));
        JPanel pnlBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlBtns.add(btnCancelar);
        pnlBtns.add(btnGuardar);
        pnlSur.add(lblAlertaModal, BorderLayout.NORTH);
        pnlSur.add(pnlBtns, BorderLayout.SOUTH);

        dlg.add(pnlForm, BorderLayout.CENTER);
        dlg.add(pnlSur, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void abrirPerfilClienteSCR06() {
        Cliente sel = obtenerClienteSeleccionado();
        if (sel == null) return;

        ConsolidadoCliente cons = clienteService.obtenerConsolidado(sel.getIdentificador());
        JDialog dlg = new JDialog(this, "Perfil del Cliente y Consolidado (SCR-06) · " + sel.getIdentificador(), true);
        dlg.setSize(760, 460);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(12, 12));

        JPanel pnlIzq = new JPanel(new GridLayout(9, 1, 4, 4));
        pnlIzq.setBorder(new TitledBorder("Datos del Perfil"));
        pnlIzq.add(new JLabel("Nombre: " + sel.getNombreCompleto()));
        pnlIzq.add(new JLabel("Código: " + sel.getIdentificador() + " · Estado: " + sel.getEstado()));
        pnlIzq.add(new JLabel("Tipo: " + sel.getTipo().getEtiqueta()));
        pnlIzq.add(new JLabel("Edad: " + (sel.getEdad() != null ? sel.getEdad() : "—")));
        pnlIzq.add(new JLabel("Teléfono: " + sel.getTelefono()));
        pnlIzq.add(new JLabel("Correo: " + (sel.getCorreo() != null ? sel.getCorreo() : "—")));
        pnlIzq.add(new JLabel("RFC: " + (sel.getRfc() != null ? sel.getRfc() : "—")));
        pnlIzq.add(new JLabel("Razón Social: " + (sel.getRazonSocial() != null ? sel.getRazonSocial() : "—")));
        pnlIzq.add(new JLabel("Última mod.: " + sel.getFechaModificacionFormateada()));

        JPanel pnlDer = new JPanel(new BorderLayout(8, 8));
        pnlDer.setBorder(new TitledBorder("Consolidado de Compras (RF-04.9)"));

        JPanel pnlResumen = new JPanel(new GridLayout(1, 3, 8, 0));
        pnlResumen.add(new JLabel("Compras: " + cons.getNumeroCompras()));
        pnlResumen.add(new JLabel("Acumulado: " + FormateadorMoneda.formatearMXN(cons.getMontoTotalAcumulado())));
        pnlResumen.add(new JLabel("Última: " + cons.getFechaUltimaCompra()));
        pnlDer.add(pnlResumen, BorderLayout.NORTH);

        DefaultTableModel modCompras = new DefaultTableModel(
                new Object[]{"Folio", "Fecha", "Subtotal", "IVA", "Total", "Factura solicitada"}, 0);
        for (Venta v : cons.getCompras()) {
            modCompras.addRow(new Object[]{
                v.getFolio(), v.getFechaFormateada(),
                FormateadorMoneda.formatear(v.getSubtotal()),
                FormateadorMoneda.formatear(v.getIva()),
                FormateadorMoneda.formatear(v.getTotal()),
                v.isRequiereFactura() ? "Sí" : "No"
            });
        }
        pnlDer.add(new JScrollPane(new JTable(modCompras)), BorderLayout.CENTER);

        dlg.add(pnlIzq, BorderLayout.WEST);
        dlg.add(pnlDer, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void accionEliminarClienteSCR12y13() {
        Cliente sel = obtenerClienteSeleccionado();
        if (sel == null) return;

        int numCompras = clienteService.contarVentas(sel.getIdentificador());
        if (numCompras > 0) {
            Object[] opciones = {"CAMBIAR A INACTIVO", "CERRAR"};
            int r = JOptionPane.showOptionDialog(this,
                    "EX-07: El cliente tiene " + numCompras + " compra(s) registrada(s).\n"
                    + "Para conservar su historial no puede eliminarse físicamente (RN-10).\n"
                    + "Puede cambiarlo a Inactivo para impedir su uso en nuevas ventas.",
                    "Bloqueo de Eliminación (EX-07 · SCR-12)",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, opciones, opciones[0]);
            if (r == 0 && sel.esActivo()) {
                clienteService.cambiarEstado(sel.getIdentificador());
                recargarTodo();
            }
        } else {
            int conf = JOptionPane.showConfirmDialog(this,
                    "Confirmar eliminación definitiva (SCR-13)\n\n"
                    + sel.getIdentificador() + " · " + sel.getNombreCompleto() + "\n"
                    + "El cliente no tiene ventas registradas.",
                    "Confirmar Eliminación (SCR-13)", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (conf == JOptionPane.YES_OPTION) {
                clienteService.eliminar(sel.getIdentificador());
                recargarTodo();
            }
        }
    }

    private void abrirDialogoProductoSCR09(Producto prodEditar) {
        boolean esMod = (prodEditar != null);
        JDialog dlg = new JDialog(this, esMod ? "Modificar Producto (SCR-09)" : "Nuevo Producto (SCR-09)", true);
        dlg.setSize(460, 340);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel pnlForm = new JPanel(new GridLayout(5, 2, 8, 8));
        pnlForm.setBorder(new EmptyBorder(14, 16, 6, 16));

        JTextField txtCod = new JTextField(esMod ? prodEditar.getCodigo() : "");
        txtCod.setEnabled(!esMod);
        JTextField txtNom = new JTextField(esMod ? prodEditar.getNombre() : "");
        JComboBox<Categoria> cmbCat = new JComboBox<>();
        for (Categoria c : categoriaService.listar()) {
            cmbCat.addItem(c);
            if (esMod && c.getNombre().equalsIgnoreCase(prodEditar.getCategoria().getNombre())) {
                cmbCat.setSelectedItem(c);
            }
        }
        JTextField txtPre = new JTextField(esMod ? String.valueOf(prodEditar.getPrecio()) : "0.00");
        JSpinner spnStockIni = new JSpinner(new SpinnerNumberModel(esMod ? prodEditar.getStock() : 0, 0, 9999, 1));
        spnStockIni.setEnabled(!esMod);

        pnlForm.add(new JLabel("Código * (único, mayúsculas):"));
        pnlForm.add(txtCod);
        pnlForm.add(new JLabel("Nombre *:"));
        pnlForm.add(txtNom);
        pnlForm.add(new JLabel("Categoría *:"));
        pnlForm.add(cmbCat);
        pnlForm.add(new JLabel("Precio de venta (sin IVA) *:"));
        pnlForm.add(txtPre);
        pnlForm.add(new JLabel("Existencia inicial *:"));
        pnlForm.add(spnStockIni);

        JButton btnGuardar = new JButton("GUARDAR (F5)");
        btnGuardar.addActionListener(e -> {
            double precioVal;
            try {
                precioVal = Double.parseDouble(txtPre.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlg, "EX-08: Ingrese un precio numérico válido mayor que cero.");
                return;
            }
            Producto p = new Producto(txtCod.getText().trim().toUpperCase(), txtNom.getText().trim(),
                    (Categoria) cmbCat.getSelectedItem(), precioVal, (Integer) spnStockIni.getValue());
            String err = esMod ? productoService.modificarProducto(p) : productoService.anadirProducto(p);
            if (err != null) {
                JOptionPane.showMessageDialog(dlg, err, "Validación de Producto (EX-08)", JOptionPane.WARNING_MESSAGE);
            } else {
                recargarTodo();
                dlg.dispose();
            }
        });

        JPanel pnlSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnCanc = new JButton("ESC Cancelar");
        btnCanc.addActionListener(e -> dlg.dispose());
        pnlSur.add(btnCanc);
        pnlSur.add(btnGuardar);

        dlg.add(pnlForm, BorderLayout.CENTER);
        dlg.add(pnlSur, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void abrirDialogoCategoriasSCR10() {
        JDialog dlg = new JDialog(this, "Administración de Categorías (SCR-10)", true);
        dlg.setSize(520, 380);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel pnlAlta = new JPanel(new BorderLayout(8, 0));
        pnlAlta.setBorder(new EmptyBorder(12, 12, 4, 12));
        JTextField txtNuevaCat = new JTextField();
        JButton btnAnadirCat = new JButton("+ AÑADIR");
        pnlAlta.add(new JLabel("Nombre de categoría:"), BorderLayout.WEST);
        pnlAlta.add(txtNuevaCat, BorderLayout.CENTER);
        pnlAlta.add(btnAnadirCat, BorderLayout.EAST);

        DefaultTableModel modCats = new DefaultTableModel(new Object[]{"ID", "Nombre", "Productos asociados"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tblCats = new JTable(modCats);

        Runnable refrescarCats = () -> {
            modCats.setRowCount(0);
            for (Categoria c : categoriaService.listar()) {
                modCats.addRow(new Object[]{c.getIdCategoria(), c.getNombre(), categoriaService.contarProductos(c.getIdCategoria())});
            }
        };
        refrescarCats.run();

        btnAnadirCat.addActionListener(e -> {
            String err = categoriaService.anadirCategoria(txtNuevaCat.getText());
            if (err != null) {
                JOptionPane.showMessageDialog(dlg, err, "Validación (EX-08)", JOptionPane.WARNING_MESSAGE);
            } else {
                txtNuevaCat.setText("");
                refrescarCats.run();
                recargarTodo();
            }
        });

        JPanel pnlSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnRenombrar = new JButton("MODIFICAR");
        btnRenombrar.addActionListener(e -> {
            int f = tblCats.getSelectedRow();
            if (f < 0) return;
            int id = (Integer) modCats.getValueAt(f, 0);
            String actual = modCats.getValueAt(f, 1).toString();
            String nuevo = JOptionPane.showInputDialog(dlg, "Nuevo nombre para la categoría:", actual);
            if (nuevo != null) {
                String err = categoriaService.modificarCategoria(id, nuevo);
                if (err != null) {
                    JOptionPane.showMessageDialog(dlg, err, "Validación (EX-08)", JOptionPane.WARNING_MESSAGE);
                } else {
                    refrescarCats.run();
                    recargarTodo();
                }
            }
        });

        JButton btnEliminarCat = new JButton("ELIMINAR");
        btnEliminarCat.addActionListener(e -> {
            int f = tblCats.getSelectedRow();
            if (f < 0) return;
            int id = (Integer) modCats.getValueAt(f, 0);
            String err = categoriaService.eliminarCategoria(id);
            if (err != null) {
                JOptionPane.showMessageDialog(dlg, err, "Bloqueo por Dependencias (EX-09)", JOptionPane.WARNING_MESSAGE);
            } else {
                refrescarCats.run();
                recargarTodo();
            }
        });

        pnlSur.add(btnRenombrar);
        pnlSur.add(btnEliminarCat);

        dlg.add(pnlAlta, BorderLayout.NORTH);
        dlg.add(new JScrollPane(tblCats), BorderLayout.CENTER);
        dlg.add(pnlSur, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void abrirDialogoStockSCR11(Producto prod, boolean esEntrada) {
        String titulo = esEntrada ? "Añadir Stock (Entrada · SCR-11)" : "Ajustar Stock (Conteo físico · SCR-11)";
        JDialog dlg = new JDialog(this, titulo, true);
        dlg.setSize(450, 270);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel pnlForm = new JPanel(new GridLayout(esEntrada ? 3 : 4, 2, 8, 8));
        pnlForm.setBorder(new EmptyBorder(14, 16, 6, 16));

        pnlForm.add(new JLabel("Producto:"));
        pnlForm.add(new JLabel(prod.getCodigo() + " · " + prod.getNombre()));
        pnlForm.add(new JLabel("Existencia actual:"));
        pnlForm.add(new JLabel(String.valueOf(prod.getStock())));

        JSpinner spnCant = new JSpinner(new SpinnerNumberModel(esEntrada ? 1 : prod.getStock(), esEntrada ? 1 : 0, 9999, 1));
        pnlForm.add(new JLabel(esEntrada ? "Cantidad que ingresa (> 0) *:" : "Nueva existencia exacta (>= 0) *:"));
        pnlForm.add(spnCant);

        JTextField txtMotivo = new JTextField();
        if (!esEntrada) {
            pnlForm.add(new JLabel("Motivo (merma/conteo) *:"));
            pnlForm.add(txtMotivo);
        }

        JButton btnGuardar = new JButton("GUARDAR (F5)");
        btnGuardar.addActionListener(e -> {
            int valor = (Integer) spnCant.getValue();
            String err = esEntrada
                    ? productoService.anadirStock(prod.getCodigo(), valor)
                    : productoService.ajustarStock(prod.getCodigo(), valor, txtMotivo.getText());
            if (err != null) {
                JOptionPane.showMessageDialog(dlg, err, "Validación de Stock (EX-08)", JOptionPane.WARNING_MESSAGE);
            } else {
                recargarTodo();
                dlg.dispose();
            }
        });

        JPanel pnlSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnCanc = new JButton("ESC Cancelar");
        btnCanc.addActionListener(e -> dlg.dispose());
        pnlSur.add(btnCanc);
        pnlSur.add(btnGuardar);

        dlg.add(pnlForm, BorderLayout.CENTER);
        dlg.add(pnlSur, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void accionEliminarProducto() {
        Producto p = obtenerProductoInventarioSeleccionado();
        if (p == null) return;

        int conf = JOptionPane.showConfirmDialog(this,
                "¿Desea eliminar el producto " + p.getCodigo() + " (" + p.getNombre() + ")?",
                "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
        if (conf == JOptionPane.YES_OPTION) {
            String err = productoService.eliminarProducto(p.getCodigo());
            if (err != null) {
                JOptionPane.showMessageDialog(this, err, "Bloqueo por Historial (EX-09)", JOptionPane.WARNING_MESSAGE);
            } else {
                recargarTodo();
            }
        }
    }

    private void mostrarBitacoraMovimientos() {
        ArrayList<MovimientoInventario> movs = inventarioService.listarMovimientos();
        StringBuilder sb = new StringBuilder("=== BITÁCORA DE MOVIMIENTOS DE INVENTARIO (RN-18) ===\n\n");
        if (movs.isEmpty()) {
            sb.append("Aún no se han registrado entradas ni ajustes manuales de stock.");
        } else {
            for (MovimientoInventario m : movs) {
                sb.append(m.mostrarResumen()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, sb.toString(), "Movimientos de Inventario", JOptionPane.INFORMATION_MESSAGE);
    }

    private void configurarAtajosTeclado() {
        JRootPane root = getRootPane();
        root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0), "BUSCAR");
        root.getActionMap().put("BUSCAR", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtBusqueda.requestFocusInWindow();
            }
        });
        root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0), "CONFIRMAR");
        root.getActionMap().put("CONFIRMAR", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn_Confirmar.isShowing() && btn_Confirmar.isEnabled()) {
                    btn_ConfirmarActionPerformed(null);
                }
            }
        });
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new FrameVista().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBcategoria;
    private javax.swing.JSpinner Spi_cantidad;
    private javax.swing.JButton btnAjustarStock;
    private javax.swing.JButton btnAnadirStock;
    private javax.swing.JButton btnCambiarEstadoCliente;
    private javax.swing.JButton btnCancelarVendedor;
    private javax.swing.JButton btnCategorias;
    private javax.swing.JButton btnEditarCliente;
    private javax.swing.JButton btnEliminarCliente;
    private javax.swing.JButton btnEliminarProducto;
    private javax.swing.JButton btnGuardarVendedor;
    private javax.swing.JButton btnHistorialMovs;
    private javax.swing.JButton btnModificarProducto;
    private javax.swing.JButton btnNuevoCliente;
    private javax.swing.JButton btnNuevoClienteRapido;
    private javax.swing.JButton btnNuevoProducto;
    private javax.swing.JButton btnVerPerfil;
    private javax.swing.JButton btn_Agregarventa;
    private javax.swing.JToggleButton btn_Confirmar;
    private javax.swing.JButton btn_Limpiar;
    private javax.swing.JButton btn_Quitar;
    private javax.swing.JCheckBox chkFactura;
    private javax.swing.JComboBox<String> cmbCategoriaInv;
    private javax.swing.JComboBox<String> cmbCliente;
    private javax.swing.JComboBox<String> cmbEstadoCliente;
    private javax.swing.JComboBox<String> cmbTipoClienteFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblAlertaStock;
    private javax.swing.JLabel lblAvisoPrivacidad;
    private javax.swing.JLabel lblFechaModVendedor;
    private javax.swing.JLabel lblVendedorHeader;
    private javax.swing.JLabel lblVentasVendedor;
    private javax.swing.JLabel lbl_IVA;
    private javax.swing.JLabel lbl_Subtotal;
    private javax.swing.JLabel lbl_Total;
    private javax.swing.JPanel pnlClientes;
    private javax.swing.JPanel pnlInventario;
    private javax.swing.JPanel pnlVendedor;
    private javax.swing.JPanel pnlVentas;
    private javax.swing.JSpinner spnEdadVendedor;
    private javax.swing.JTabbedPane tabbedVistas;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTable tblInventario;
    private javax.swing.JTable tbl_lista;
    private javax.swing.JTable tbl_productos;
    private javax.swing.JTextField txtApellidoVendedor;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtBusquedaCliente;
    private javax.swing.JTextField txtBusquedaInv;
    private javax.swing.JTextField txtNombreVendedor;
    // End of variables declaration//GEN-END:variables
}
