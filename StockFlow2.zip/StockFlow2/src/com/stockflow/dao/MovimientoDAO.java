package com.stockflow.dao;

import com.stockflow.modelo.Categoria;
import com.stockflow.modelo.MovimientoInventario;
import com.stockflow.modelo.Producto;
import com.stockflow.modelo.TipoMovimiento;
import com.stockflow.modelo.Vendedor;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class MovimientoDAO implements RepositorioMovimiento {

    @Override
    public int siguienteId() {
        BaseDatosMemoria.secuenciaMovimiento++;
        return BaseDatosMemoria.secuenciaMovimiento;
    }

    @Override
    public boolean registrar(MovimientoInventario m) {
        if (m == null) return false;
        if (ConexionBD.probarConexion()) {
            String sql = "INSERT INTO movimiento_inventario "
                       + "(codigo_producto, id_vendedor, tipo, cantidad, existencia_anterior, existencia_nueva, motivo, fecha_hora) "
                       + "VALUES (?, 1, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, m.getProducto().getCodigo());
                ps.setString(2, m.getTipo() == TipoMovimiento.ENTRADA ? "ENTRADA" : "AJUSTE");
                ps.setInt(3, m.getCantidad());
                ps.setInt(4, m.getExistenciaAnterior());
                ps.setInt(5, m.getExistenciaNueva());
                ps.setString(6, m.getMotivo());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error MovimientoDAO.registrar]: " + e.getMessage());
                return false;
            }
        }
        BaseDatosMemoria.MOVIMIENTOS.add(0, m);
        return true;
    }

    @Override
    public ArrayList<MovimientoInventario> listarPorProducto(String codigo) {
        ArrayList<MovimientoInventario> lista = new ArrayList<>();
        for (MovimientoInventario m : listarTodos()) {
            if (m.getProducto().getIdentificador().equalsIgnoreCase(codigo)) {
                lista.add(m);
            }
        }
        return lista;
    }

    @Override
    public ArrayList<MovimientoInventario> listarTodos() {
        if (ConexionBD.probarConexion()) {
            ArrayList<MovimientoInventario> lista = new ArrayList<>();
            Vendedor vend = new VendedorDAO().obtener();
            String sql = "SELECT m.id_movimiento, m.codigo_producto, m.tipo, m.cantidad, "
                       + "m.existencia_anterior, m.existencia_nueva, m.motivo, m.fecha_hora, "
                       + "p.nombre AS prod_nombre, p.precio, p.stock, c.id_categoria, c.nombre AS cat_nombre "
                       + "FROM movimiento_inventario m "
                       + "JOIN producto p ON m.codigo_producto = p.codigo "
                       + "JOIN categoria c ON p.id_categoria = c.id_categoria "
                       + "ORDER BY m.fecha_hora DESC, m.id_movimiento DESC";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Categoria cat = new Categoria(rs.getInt("id_categoria"), rs.getString("cat_nombre"));
                    Producto prod = new Producto(
                            rs.getString("codigo_producto"),
                            rs.getString("prod_nombre"),
                            cat,
                            rs.getDouble("precio"),
                            rs.getInt("stock")
                    );
                    TipoMovimiento tipo = "ENTRADA".equalsIgnoreCase(rs.getString("tipo"))
                            ? TipoMovimiento.ENTRADA
                            : TipoMovimiento.AJUSTE;
                    
                    MovimientoInventario mov = new MovimientoInventario(
                            rs.getInt("id_movimiento"),
                            prod,
                            tipo,
                            rs.getInt("cantidad"),
                            rs.getInt("existencia_anterior"),
                            rs.getInt("existencia_nueva"),
                            rs.getString("motivo"),
                            vend
                    );
                    
                    // Asignación limpia de la fecha usando rs.getTimestamp directamente
                    Timestamp ts = rs.getTimestamp("fecha_hora");
                    if (ts != null) {
                        mov.setFecha(ts.toLocalDateTime());
                    }
                    
                    lista.add(mov);
                }
                return lista;
            } catch (Exception e) {
                System.err.println("[Error MovimientoDAO.listarTodos]: " + e.getMessage());
            }
        }
        return BaseDatosMemoria.MOVIMIENTOS;
    }
}