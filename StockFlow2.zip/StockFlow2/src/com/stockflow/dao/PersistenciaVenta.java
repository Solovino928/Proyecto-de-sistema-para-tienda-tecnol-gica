package com.stockflow.dao;

import com.stockflow.modelo.Venta;

public interface PersistenciaVenta {
    boolean registrarVenta(Venta venta);
}
