/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.dao;
import com.stockflow.modelo.Categoria;
import com.stockflow.modelo.Producto;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */

public class ProductoDAO implements RepositorioProducto {
    private ArrayList<Producto> productos = new ArrayList<>();

    public ProductoDAO() {
        Categoria perifericos = new Categoria("Perifericos");
        Categoria almacenamiento = new Categoria("Almacenamiento");
        Categoria accesorios = new Categoria("Accesorios y conectividad");

        productos.add(new Producto("PER-001", "Teclado mecánico RGB", perifericos, 850.00, 12));
        productos.add(new Producto("PER-003", "Mouse inalámbrico", perifericos, 250.00, 20));
        productos.add(new Producto("PER-007", "Cámara web Full HD", perifericos, 720.00, 6));
        productos.add(new Producto("ALM-002", "Memoria USB 64 GB", almacenamiento, 180.00, 25));
        productos.add(new Producto("ALM-007", "SSD SATA 480 GB", almacenamiento, 690.00, 8));
        productos.add(new Producto("ALM-009", "Disco duro externo 1 TB", almacenamiento, 1250.00, 5));
        productos.add(new Producto("ACC-001", "Cable HDMI 2 metros", accesorios, 150.00, 20));
        productos.add(new Producto("ACC-003", "Adaptador USB-C a HDMI", accesorios, 350.00, 12));
        productos.add(new Producto("ACC-004", "Hub USB de 4 puertos", accesorios, 290.00, 10));
        productos.add(new Producto("ACC-010", "Soporte ajustable para laptop", accesorios, 320.00, 0));
    }

    @Override
    public ArrayList<Producto> listar() {
        return productos;
    }

    @Override
    public Producto buscarCodigo(String codigo) {
        for (Producto p : productos) {
            if (p.getIdentificador().equalsIgnoreCase(codigo)) {
                return p;
            }
        }
        return null;
    }
}
