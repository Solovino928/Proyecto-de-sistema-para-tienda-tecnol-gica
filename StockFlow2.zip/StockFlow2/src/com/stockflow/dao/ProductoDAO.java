package com.stockflow.dao;

import com.stockflow.modelo.Categoria;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import com.stockflow.modelo.Venta;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProductoDAO implements RepositorioProducto {

    @Override
    public ArrayList<Producto> listar() {
        if (ConexionBD.probarConexion()) {
            ArrayList<Producto> lista = new ArrayList<>();
            String sql = "SELECT p.codigo, p.nombre, p.precio, p.stock, c.id_categoria, c.nombre AS cat_nombre "
                       + "FROM producto p "
                       + "JOIN categoria c ON p.id_categoria = c.id_categoria "
                       + "ORDER BY p.codigo";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Categoria cat = new Categoria(rs.getInt("id_categoria"), rs.getString("cat_nombre"));
                    Producto p = new Producto(
                            rs.getString("codigo"),
                            rs.getString("nombre"),
                            cat,
                            rs.getDouble("precio"),
                            rs.getInt("stock")
                    );
                    lista.add(p);
                }
                return lista;
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.listar]: " + e.getMessage());
            }
        }
        return BaseDatosMemoria.PRODUCTOS;
    }

    @Override
    public Producto buscarCodigo(String codigo) {
        if (codigo == null) return null;
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT p.codigo, p.nombre, p.precio, p.stock, c.id_categoria, c.nombre AS cat_nombre "
                       + "FROM producto p "
                       + "JOIN categoria c ON p.id_categoria = c.id_categoria "
                       + "WHERE UPPER(p.codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Categoria cat = new Categoria(rs.getInt("id_categoria"), rs.getString("cat_nombre"));
                        return new Producto(
                                rs.getString("codigo"),
                                rs.getString("nombre"),
                                cat,
                                rs.getDouble("precio"),
                                rs.getInt("stock")
                        );
                    }
                    return null;
                }
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.buscarCodigo]: " + e.getMessage());
            }
        }
        for (Producto p : BaseDatosMemoria.PRODUCTOS) {
            if (p.getIdentificador().equalsIgnoreCase(codigo.trim())) {
                return p;
            }
        }
        return null;
    }

    @Override
    public boolean existeCodigo(String codigo) {
        return buscarCodigo(codigo) != null;
    }

    // RN-16 / EX-09: Verifica en detalle_orden si el producto tiene ventas registradas
    @Override
    public boolean tieneVentas(String codigo) {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT COUNT(*) FROM detalle_orden WHERE UPPER(codigo_producto) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt(1) > 0;
                    }
                }
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.tieneVentas]: " + e.getMessage());
            }
        }
        for (Venta v : BaseDatosMemoria.ORDENES) {
            for (DetalleVenta d : v.getDetalles()) {
                if (d.getProducto().getIdentificador().equalsIgnoreCase(codigo)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean insertar(Producto p) {
        if (p == null) return false;
        if (ConexionBD.probarConexion()) {
            String sql = "INSERT INTO producto (codigo, id_categoria, nombre, precio, stock) VALUES (UPPER(?), ?, ?, ?, ?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, p.getCodigo().trim());
                ps.setInt(2, p.getCategoria().getIdCategoria());
                ps.setString(3, p.getNombre().trim());
                ps.setDouble(4, p.getPrecio());
                ps.setInt(5, p.getStock());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.insertar]: " + e.getMessage());
                return false;
            }
        }
        if (existeCodigo(p.getCodigo())) return false;
        BaseDatosMemoria.PRODUCTOS.add(p);
        return true;
    }

    @Override
    public boolean actualizar(Producto p) {
        if (p == null) return false;
        if (ConexionBD.probarConexion()) {
            String sql = "UPDATE producto SET nombre = ?, id_categoria = ?, precio = ? WHERE UPPER(codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, p.getNombre().trim());
                ps.setInt(2, p.getCategoria().getIdCategoria());
                ps.setDouble(3, p.getPrecio());
                ps.setString(4, p.getCodigo().trim());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.actualizar]: " + e.getMessage());
                return false;
            }
        }
        Producto existente = buscarCodigo(p.getCodigo());
        if (existente == null) return false;
        existente.setNombre(p.getNombre());
        existente.setCategoria(p.getCategoria());
        existente.setPrecio(p.getPrecio());
        return true;
    }

    @Override
    public boolean borrar(String codigo) {
        if (tieneVentas(codigo)) return false;
        if (ConexionBD.probarConexion()) {
            String sql = "DELETE FROM producto WHERE UPPER(codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.borrar]: " + e.getMessage());
                return false;
            }
        }
        Producto existente = buscarCodigo(codigo);
        if (existente != null) {
            BaseDatosMemoria.PRODUCTOS.remove(existente);
            return true;
        }
        return false;
    }

    @Override
    public boolean actualizarStock(String codigo, int nuevoStock) {
        if (nuevoStock < 0) return false;
        if (ConexionBD.probarConexion()) {
            String sql = "UPDATE producto SET stock = ? WHERE UPPER(codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, nuevoStock);
                ps.setString(2, codigo.trim());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error ProductoDAO.actualizarStock]: " + e.getMessage());
                return false;
            }
        }
        Producto existente = buscarCodigo(codigo);
        if (existente == null) return false;
        existente.setStock(nuevoStock);
        return true;
    }
}
