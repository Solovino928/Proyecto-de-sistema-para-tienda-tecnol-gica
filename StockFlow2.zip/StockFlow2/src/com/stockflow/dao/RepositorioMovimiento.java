package com.stockflow.dao;

import com.stockflow.modelo.MovimientoInventario;
import java.util.ArrayList;

public interface RepositorioMovimiento {
    boolean registrar(MovimientoInventario m);
    ArrayList<MovimientoInventario> listarPorProducto(String codigo);
    ArrayList<MovimientoInventario> listarTodos();
    int siguienteId();
}
