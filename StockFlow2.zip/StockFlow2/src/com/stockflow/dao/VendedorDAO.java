package com.stockflow.dao;

import com.stockflow.modelo.Vendedor;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

public class VendedorDAO implements RepositorioVendedor {

    @Override
    public Vendedor obtener() {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT id_vendedor, nombre, apellido, edad, fecha_modificacion FROM vendedor WHERE id_vendedor = 1";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Vendedor v = new Vendedor(
                            String.valueOf(rs.getInt("id_vendedor")),
                            rs.getString("nombre"),
                            rs.getString("apellido"),
                            rs.getInt("edad")
                    );
                    Timestamp ts = rs.getTimestamp("fecha_modificacion");
                    if (ts != null) {
                        v.setFechaModificacion(ts.toLocalDateTime());
                    }
                    return v;
                }
            } catch (Exception e) {
                System.err.println("[Error VendedorDAO.obtener]: " + e.getMessage());
            }
        }
        return BaseDatosMemoria.VENDEDOR_UNICO;
    }

    @Override
    public void actualizar(Vendedor v) {
        if (ConexionBD.probarConexion()) {
            String sql = "UPDATE vendedor SET nombre = ?, apellido = ?, edad = ?, fecha_modificacion = CURRENT_TIMESTAMP WHERE id_vendedor = 1";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, v.getNombre().trim());
                ps.setString(2, v.getApellido().trim());
                ps.setInt(3, v.getEdad());
                ps.executeUpdate();
                return;
            } catch (Exception e) {
                System.err.println("[Error VendedorDAO.actualizar]: " + e.getMessage());
            }
        }
        BaseDatosMemoria.VENDEDOR_UNICO = v;
    }
}
