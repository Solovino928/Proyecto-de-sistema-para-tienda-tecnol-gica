package com.stockflow.dao;

import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class FolioGeneratorDAO {

    public String generarFolio() {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT 'STKD-2026-' || LPAD(nextval('seq_folio')::TEXT, 4, '0') AS folio";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("folio");
                }
            } catch (Exception e) {
                System.err.println("Aviso FolioGeneratorDAO (usando memoria): " + e.getMessage());
            }
        }
        BaseDatosMemoria.secuenciaFolio++;
        return String.format("STKD-2026-%04d", BaseDatosMemoria.secuenciaFolio);
    }
}
