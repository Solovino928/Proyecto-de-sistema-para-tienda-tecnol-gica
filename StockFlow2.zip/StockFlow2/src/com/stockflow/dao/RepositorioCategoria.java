package com.stockflow.dao;

import com.stockflow.modelo.Categoria;
import java.util.ArrayList;

public interface RepositorioCategoria {
    ArrayList<Categoria> listar();
    Categoria buscarPorId(int id);
    boolean existeNombre(String nombre, int idIgnorar);
    int contarProductos(int idCategoria);
    boolean insertar(Categoria c);
    boolean actualizar(Categoria c);
    boolean borrar(int idCategoria);
}
