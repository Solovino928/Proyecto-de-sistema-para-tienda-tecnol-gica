package com.stockflow.dao;

import com.stockflow.modelo.Vendedor;

public interface RepositorioVendedor {
    Vendedor obtener();
    void actualizar(Vendedor v);
}
