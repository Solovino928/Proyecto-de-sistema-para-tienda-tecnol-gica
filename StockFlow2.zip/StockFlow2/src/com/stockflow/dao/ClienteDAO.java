package com.stockflow.dao;

import com.stockflow.modelo.Cliente;
import com.stockflow.modelo.EstadoCliente;
import com.stockflow.modelo.TipoCliente;
import com.stockflow.modelo.Venta;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;

public class ClienteDAO implements RepositorioCliente {

    private Cliente mapearCliente(ResultSet rs) throws Exception {
        Integer edad = rs.getObject("edad") != null ? rs.getInt("edad") : null;
        String tipoStr = rs.getString("tipo");
        TipoCliente tipo = "MORAL".equalsIgnoreCase(tipoStr)
                ? TipoCliente.PERSONA_MORAL
                : TipoCliente.PERSONA_FISICA;

        Cliente c = new Cliente(
                rs.getString("codigo"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                edad,
                rs.getString("telefono"),
                rs.getString("correo"),
                rs.getString("rfc"),
                rs.getString("razon_social"),
                tipo
        );

        String estadoStr = rs.getString("estado");
        if ("INACTIVO".equalsIgnoreCase(estadoStr)) {
            c.setEstado(EstadoCliente.INACTIVO);
        } else {
            c.setEstado(EstadoCliente.ACTIVO);
        }

        // Lectura segura basada en texto plano para evitar conflictos en NetBeans
        try {
            String fReg = rs.getString("fecha_registro");
            if (fReg != null && fReg.length() >= 19) {
                c.setFechaRegistro(java.time.LocalDateTime.parse(fReg.substring(0, 19).replace(" ", "T")));
            }
        } catch (Exception ignore) {}

        try {
            String fMod = rs.getString("fecha_modificacion");
            if (fMod != null && fMod.length() >= 19) {
                c.setFechaModificacion(java.time.LocalDateTime.parse(fMod.substring(0, 19).replace(" ", "T")));
            } else if (c.getFechaRegistro() != null) {
                c.setFechaModificacion(c.getFechaRegistro());
            }
        } catch (Exception ignore) {}

        return c;
    }


    @Override
    public String previsualizarSiguienteCodigo() {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT 'CLI-' || LPAD((last_value + CASE WHEN is_called THEN 1 ELSE 0 END)::TEXT, 4, '0') FROM seq_cliente";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            } catch (Exception e) {
                System.err.println("[Aviso ClienteDAO.previsualizarSiguienteCodigo]: " + e.getMessage());
            }
        }
        return String.format("CLI-%04d", BaseDatosMemoria.secuenciaCliente + 1);
    }

    @Override
    public String insertar(Cliente c) {
        if (ConexionBD.probarConexion()) {
            String sqlSeq = "SELECT 'CLI-' || LPAD(nextval('seq_cliente')::TEXT, 4, '0')";
            String sqlIns = "INSERT INTO cliente (codigo, nombre, apellido, edad, telefono, correo, rfc, razon_social, tipo, estado, fecha_registro, fecha_modificacion) "
                          + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVO', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
            try (Connection conn = ConexionBD.obtenerConexion()) {
                String codigoNuevo = null;
                try (PreparedStatement psSeq = conn.prepareStatement(sqlSeq);
                     ResultSet rs = psSeq.executeQuery()) {
                    if (rs.next()) codigoNuevo = rs.getString(1);
                }
                if (codigoNuevo == null) {
                    codigoNuevo = previsualizarSiguienteCodigo();
                }

                try (PreparedStatement ps = conn.prepareStatement(sqlIns)) {
                    ps.setString(1, codigoNuevo);
                    ps.setString(2, c.getNombre().trim());
                    ps.setString(3, c.getApellido().trim());
                    if (c.getEdad() != null) ps.setInt(4, c.getEdad());
                    else ps.setNull(4, Types.INTEGER);
                    ps.setString(5, c.getTelefono().replaceAll("\\s+", ""));
                    if (c.getCorreo() != null && !c.getCorreo().isBlank()) ps.setString(6, c.getCorreo().trim());
                    else ps.setNull(6, Types.VARCHAR);
                    if (c.getRfc() != null && !c.getRfc().isBlank()) ps.setString(7, c.getRfc().trim().toUpperCase());
                    else ps.setNull(7, Types.VARCHAR);
                    if (c.getRazonSocial() != null && !c.getRazonSocial().isBlank()) ps.setString(8, c.getRazonSocial().trim());
                    else ps.setNull(8, Types.VARCHAR);
                    ps.setString(9, c.getTipo().getClaveBD());
                    ps.executeUpdate();
                }
                c.setIdentificador(codigoNuevo);
                return codigoNuevo;
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.insertar]: " + e.getMessage());
            }
        }
        BaseDatosMemoria.secuenciaCliente++;
        String codigo = String.format("CLI-%04d", BaseDatosMemoria.secuenciaCliente);
        c.setIdentificador(codigo);
        BaseDatosMemoria.CLIENTES.add(c);
        return codigo;
    }

    @Override
    public void actualizar(Cliente c) {
        c.registrarModificacion();
        if (ConexionBD.probarConexion()) {
            String sql = "UPDATE cliente SET nombre = ?, apellido = ?, edad = ?, telefono = ?, correo = ?, "
                       + "rfc = ?, razon_social = ?, tipo = ?, estado = ?, fecha_modificacion = CURRENT_TIMESTAMP "
                       + "WHERE UPPER(codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getNombre().trim());
                ps.setString(2, c.getApellido().trim());
                if (c.getEdad() != null) ps.setInt(3, c.getEdad());
                else ps.setNull(3, Types.INTEGER);
                ps.setString(4, c.getTelefono().replaceAll("\\s+", ""));
                if (c.getCorreo() != null && !c.getCorreo().isBlank()) ps.setString(5, c.getCorreo().trim());
                else ps.setNull(5, Types.VARCHAR);
                if (c.getRfc() != null && !c.getRfc().isBlank()) ps.setString(6, c.getRfc().trim().toUpperCase());
                else ps.setNull(6, Types.VARCHAR);
                if (c.getRazonSocial() != null && !c.getRazonSocial().isBlank()) ps.setString(7, c.getRazonSocial().trim());
                else ps.setNull(7, Types.VARCHAR);
                ps.setString(8, c.getTipo().getClaveBD());
                ps.setString(9, c.esActivo() ? "ACTIVO" : "INACTIVO");
                ps.setString(10, c.getIdentificador());
                ps.executeUpdate();
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.actualizar]: " + e.getMessage());
            }
        }
    }

    // RF-04.10 / RN-10: Solo elimina físicamente si no tiene ventas asociadas
    @Override
    public boolean eliminar(String codigo) {
        if (contarVentas(codigo) > 0) {
            return false;
        }
        if (ConexionBD.probarConexion()) {
            String sql = "DELETE FROM cliente WHERE UPPER(codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.eliminar]: " + e.getMessage());
                return false;
            }
        }
        Cliente c = buscarCodigo(codigo);
        if (c != null) {
            BaseDatosMemoria.CLIENTES.remove(c);
            return true;
        }
        return false;
    }

    @Override
    public ArrayList<Cliente> listar() {
        if (ConexionBD.probarConexion()) {
            ArrayList<Cliente> lista = new ArrayList<>();
            String sql = "SELECT * FROM cliente ORDER BY codigo";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearCliente(rs));
                }
                return lista;
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.listar]: " + e.getMessage());
            }
        }
        return BaseDatosMemoria.CLIENTES;
    }

    @Override
    public Cliente buscarCodigo(String codigo) {
        if (codigo == null) return null;
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT * FROM cliente WHERE UPPER(codigo) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return mapearCliente(rs);
                    return null;
                }
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.buscarCodigo]: " + e.getMessage());
            }
        }
        for (Cliente c : BaseDatosMemoria.CLIENTES) {
            if (c.getIdentificador().equalsIgnoreCase(codigo.trim())) {
                return c;
            }
        }
        return null;
    }

    @Override
    public Cliente buscarPorRfc(String rfc) {
        if (rfc == null || rfc.isBlank()) return null;
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT * FROM cliente WHERE UPPER(rfc) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, rfc.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return mapearCliente(rs);
                    return null;
                }
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.buscarPorRfc]: " + e.getMessage());
            }
        }
        for (Cliente c : BaseDatosMemoria.CLIENTES) {
            if (c.getRfc() != null && c.getRfc().equalsIgnoreCase(rfc.trim())) {
                return c;
            }
        }
        return null;
    }

    @Override
    public Cliente buscarPorCorreo(String correo) {
        if (correo == null || correo.isBlank()) return null;
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT * FROM cliente WHERE LOWER(correo) = LOWER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, correo.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return mapearCliente(rs);
                    return null;
                }
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.buscarPorCorreo]: " + e.getMessage());
            }
        }
        for (Cliente c : BaseDatosMemoria.CLIENTES) {
            if (c.getCorreo() != null && c.getCorreo().equalsIgnoreCase(correo.trim())) {
                return c;
            }
        }
        return null;
    }

    @Override
    public ArrayList<Venta> ventasDe(String codigo) {
        if (ConexionBD.probarConexion()) {
            ArrayList<Venta> resultado = new ArrayList<>();
            Cliente cli = buscarCodigo(codigo);
            VendedorDAO vendDAO = new VendedorDAO();
            String sql = "SELECT folio, fecha_hora, requiere_factura, subtotal, iva, total "
                       + "FROM orden WHERE UPPER(codigo_cliente) = UPPER(?) ORDER BY fecha_hora DESC";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Venta v = new Venta(
                                rs.getString("folio"),
                                vendDAO.obtener(),
                                cli,
                                rs.getBoolean("requiere_factura"),
                                new ArrayList<>(),
                                rs.getDouble("subtotal"),
                                rs.getDouble("iva"),
                                rs.getDouble("total")
                        );
                        
                        // Lectura universal de la fecha sin Timestamp
                        try {
                            Object objFecha = rs.getObject("fecha_hora");
                            if (objFecha != null) {
                                v.setFecha(java.time.LocalDateTime.parse(objFecha.toString().replace(" ", "T").substring(0, 19)));
                            }
                        } catch (Exception ignore) {}

                        resultado.add(v);
                    }
                }
                return resultado;
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.ventasDe]: " + e.getMessage());
            }
        }
        ArrayList<Venta> resultado = new ArrayList<>();
        for (Venta v : BaseDatosMemoria.ORDENES) {
            if (v.getCliente() != null && v.getCliente().getIdentificador().equalsIgnoreCase(codigo)) {
                resultado.add(v);
            }
        }
        return resultado;
    }

    @Override
    public int contarVentas(String codigo) {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT COUNT(*) FROM orden WHERE UPPER(codigo_cliente) = UPPER(?)";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, codigo.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt(1);
                }
            } catch (Exception e) {
                System.err.println("[Error ClienteDAO.contarVentas]: " + e.getMessage());
            }
        }
        return ventasDe(codigo).size();
    }
}
