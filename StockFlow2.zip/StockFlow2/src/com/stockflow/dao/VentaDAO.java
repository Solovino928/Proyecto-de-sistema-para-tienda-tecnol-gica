package com.stockflow.dao;

import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Venta;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;

public class VentaDAO implements PersistenciaVenta {
    private FolioGeneratorDAO folioGenerator = new FolioGeneratorDAO();

    @Override
    public boolean registrarVenta(Venta venta) {
        if (venta == null || venta.getDetalles().isEmpty()) {
            return false;
        }

        // 1. Verificación atómica previa de existencias (RNF-03 / EX-03)
        for (DetalleVenta d : venta.getDetalles()) {
            if (!d.getProducto().hayStock(d.getCantidad())) {
                return false;
            }
        }

        // 2. Si PostgreSQL (Docker) está activo, ejecuta la transacción atómica real en BD
        if (ConexionBD.probarConexion()) {
            Connection conn = null;
            try {
                conn = ConexionBD.obtenerConexion();
                conn.setAutoCommit(false); // Inicio de bloque atómico (RNF-03 / RN-06)

                String folioBD = null;
                try (PreparedStatement psFolio = conn.prepareStatement(
                        "SELECT 'STKD-2026-' || LPAD(nextval('seq_folio')::TEXT, 4, '0')")) {
                    try (ResultSet rs = psFolio.executeQuery()) {
                        if (rs.next()) {
                            folioBD = rs.getString(1);
                        }
                    }
                }
                if (folioBD == null) {
                    folioBD = folioGenerator.generarFolio();
                }

                // Insertar cabecera en tabla orden
                String sqlOrden = "INSERT INTO orden (folio, id_vendedor, codigo_cliente, requiere_factura, subtotal, iva, total) "
                        + "VALUES (?, 1, ?, ?, ?, ?, ?)";
                try (PreparedStatement psOrd = conn.prepareStatement(sqlOrden)) {
                    psOrd.setString(1, folioBD);
                    if (venta.getCliente() != null) {
                        psOrd.setString(2, venta.getCliente().getIdentificador());
                    } else {
                        psOrd.setNull(2, Types.VARCHAR);
                    }
                    psOrd.setBoolean(3, venta.isRequiereFactura());
                    psOrd.setDouble(4, venta.getSubtotal());
                    psOrd.setDouble(5, venta.getIva());
                    psOrd.setDouble(6, venta.getTotal());
                    psOrd.executeUpdate();
                }

                // Insertar partidas en detalle_orden y descontar stock en producto
                String sqlDetalle = "INSERT INTO detalle_orden (folio_orden, codigo_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
                String sqlStock = "UPDATE producto SET stock = stock - ? WHERE codigo = ? AND stock >= ?";

                try (PreparedStatement psDet = conn.prepareStatement(sqlDetalle);
                     PreparedStatement psStk = conn.prepareStatement(sqlStock)) {
                    for (DetalleVenta d : venta.getDetalles()) {
                        psStk.setInt(1, d.getCantidad());
                        psStk.setString(2, d.getProducto().getIdentificador());
                        psStk.setInt(3, d.getCantidad());
                        int filas = psStk.executeUpdate();
                        if (filas == 0) {
                            conn.rollback();
                            return false;
                        }

                        psDet.setString(1, folioBD);
                        psDet.setString(2, d.getProducto().getIdentificador());
                        psDet.setInt(3, d.getCantidad());
                        psDet.setDouble(4, d.getPrecioUnitario());
                        psDet.executeUpdate();
                    }
                }

                conn.commit(); // Confirmación atómica exitosa
                System.out.println("[PostgreSQL OK] Venta guardada en BD con folio: " + folioBD);

                // Sincronizar también el estado en memoria de la vista
                for (DetalleVenta d : venta.getDetalles()) {
                    d.getProducto().descontarStock(d.getCantidad());
                }
                venta.setFolio(folioBD);
                BaseDatosMemoria.ORDENES.add(0, venta);
                return true;

            } catch (Exception ex) {
                System.err.println("[Error JDBC - Aplicando ROLLBACK]: " + ex.getMessage());
                if (conn != null) {
                    try { conn.rollback(); } catch (Exception ignore) {}
                }
                return false;
            } finally {
                if (conn != null) {
                    try { conn.setAutoCommit(true); conn.close(); } catch (Exception ignore) {}
                }
            }
        }

        // 3. Respaldo en memoria si aún no se ha encendido Docker
        for (DetalleVenta d : venta.getDetalles()) {
            d.getProducto().descontarStock(d.getCantidad());
        }

        String folio = folioGenerator.generarFolio();
        venta.setFolio(folio);
        BaseDatosMemoria.ORDENES.add(0, venta);
        System.out.println("[Memoria Local] Venta registrada en memoria con folio: " + folio);
        return true;
    }

    public ArrayList<Venta> listarTodas() {
        return BaseDatosMemoria.ORDENES;
    }
}
