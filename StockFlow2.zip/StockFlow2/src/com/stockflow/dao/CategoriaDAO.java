package com.stockflow.dao;

import com.stockflow.modelo.Categoria;
import com.stockflow.modelo.Producto;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.Normalizer;
import java.util.ArrayList;

public class CategoriaDAO implements RepositorioCategoria {

    private String normalizar(String texto) {
        if (texto == null) return "";
        String n = Normalizer.normalize(texto.trim().toLowerCase(), Normalizer.Form.NFD);
        return n.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
    }

    @Override
    public ArrayList<Categoria> listar() {
        if (ConexionBD.probarConexion()) {
            ArrayList<Categoria> lista = new ArrayList<>();
            String sql = "SELECT id_categoria, nombre FROM categoria ORDER BY id_categoria";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Categoria(rs.getInt("id_categoria"), rs.getString("nombre")));
                }
                return lista;
            } catch (Exception e) {
                System.err.println("[Error CategoriaDAO.listar]: " + e.getMessage());
            }
        }
        return BaseDatosMemoria.CATEGORIAS;
    }

    @Override
    public Categoria buscarPorId(int id) {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT id_categoria, nombre FROM categoria WHERE id_categoria = ?";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new Categoria(rs.getInt("id_categoria"), rs.getString("nombre"));
                    }
                    return null;
                }
            } catch (Exception e) {
                System.err.println("[Error CategoriaDAO.buscarPorId]: " + e.getMessage());
            }
        }
        for (Categoria c : BaseDatosMemoria.CATEGORIAS) {
            if (c.getIdCategoria() == id) return c;
        }
        return null;
    }

    // RN-15: El nombre de una categoría es único sin distinguir mayúsculas ni acentos
    @Override
    public boolean existeNombre(String nombre, int idIgnorar) {
        String buscado = normalizar(nombre);
        for (Categoria c : listar()) {
            if (c.getIdCategoria() != idIgnorar && normalizar(c.getNombre()).equals(buscado)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int contarProductos(int idCategoria) {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT COUNT(*) FROM producto WHERE id_categoria = ?";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idCategoria);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            } catch (Exception e) {
                System.err.println("[Error CategoriaDAO.contarProductos]: " + e.getMessage());
            }
        }
        int contador = 0;
        for (Producto p : BaseDatosMemoria.PRODUCTOS) {
            if (p.getCategoria().getIdCategoria() == idCategoria) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public boolean insertar(Categoria c) {
        if (ConexionBD.probarConexion()) {
            String sql = "INSERT INTO categoria (nombre) VALUES (?) RETURNING id_categoria";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getNombre().trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        c.setIdCategoria(rs.getInt(1));
                    }
                }
                return true;
            } catch (Exception e) {
                System.err.println("[Error CategoriaDAO.insertar]: " + e.getMessage());
                return false;
            }
        }
        BaseDatosMemoria.secuenciaCategoria++;
        c.setIdCategoria(BaseDatosMemoria.secuenciaCategoria);
        BaseDatosMemoria.CATEGORIAS.add(c);
        return true;
    }

    @Override
    public boolean actualizar(Categoria c) {
        if (ConexionBD.probarConexion()) {
            String sql = "UPDATE categoria SET nombre = ? WHERE id_categoria = ?";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getNombre().trim());
                ps.setInt(2, c.getIdCategoria());
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error CategoriaDAO.actualizar]: " + e.getMessage());
                return false;
            }
        }
        Categoria actual = buscarPorId(c.getIdCategoria());
        if (actual == null) return false;
        actual.setNombre(c.getNombre());
        return true;
    }

    @Override
    public boolean borrar(int idCategoria) {
        if (contarProductos(idCategoria) > 0) return false;
        if (ConexionBD.probarConexion()) {
            String sql = "DELETE FROM categoria WHERE id_categoria = ?";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idCategoria);
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                System.err.println("[Error CategoriaDAO.borrar]: " + e.getMessage());
                return false;
            }
        }
        Categoria actual = buscarPorId(idCategoria);
        if (actual != null) {
            BaseDatosMemoria.CATEGORIAS.remove(actual);
            return true;
        }
        return false;
    }
}
