package com.stockflow.dao;

import com.stockflow.modelo.*;
import java.util.ArrayList;

/**
 * Almacén central en memoria que simula las 7 tablas del documento STKD_DBD_V3_0_291026.
 * Cuando se conecte PostgreSQL/SQLite en la Iteración 4, solo se reemplazan los DAOs.
 */
public class BaseDatosMemoria {
    public static final ArrayList<Categoria> CATEGORIAS = new ArrayList<>();
    public static final ArrayList<Producto> PRODUCTOS = new ArrayList<>();
    public static final ArrayList<Cliente> CLIENTES = new ArrayList<>();
    public static final ArrayList<Venta> ORDENES = new ArrayList<>();
    public static final ArrayList<MovimientoInventario> MOVIMIENTOS = new ArrayList<>();
    public static Vendedor VENDEDOR_UNICO;

    public static int secuenciaCategoria = 3;
    public static int secuenciaCliente = 5;
    public static int secuenciaFolio = 0;
    public static int secuenciaMovimiento = 0;

    static {
        // 1. Vendedor único inicial (RN-11, SCR-01 a SCR-07)
        VENDEDOR_UNICO = new Vendedor("1", "Laura", "Mendoza Cruz", 28);

        // 2. Categorías oficiales (SCR-01 y SCR-10)
        Categoria catPerifericos = new Categoria(1, "Perifericos");
        Categoria catAlmacenamiento = new Categoria(2, "Almacenamiento");
        Categoria catAccesorios = new Categoria(3, "Accesorios y conectividad");
        CATEGORIAS.add(catPerifericos);
        CATEGORIAS.add(catAlmacenamiento);
        CATEGORIAS.add(catAccesorios);

        // 3. Catálogo oficial de 10 productos (Sección 3 de STKD_MCK_V0_3_291026)
        PRODUCTOS.add(new Producto("PER-001", "Teclado mecánico RGB", catPerifericos, 850.00, 12));
        PRODUCTOS.add(new Producto("PER-003", "Mouse inalámbrico", catPerifericos, 250.00, 20));
        PRODUCTOS.add(new Producto("PER-007", "Cámara web Full HD", catPerifericos, 720.00, 6));
        PRODUCTOS.add(new Producto("ALM-002", "Memoria USB 64 GB", catAlmacenamiento, 180.00, 25));
        PRODUCTOS.add(new Producto("ALM-007", "SSD SATA 480 GB", catAlmacenamiento, 690.00, 8));
        PRODUCTOS.add(new Producto("ALM-009", "Disco duro externo 1 TB", catAlmacenamiento, 1250.00, 5));
        PRODUCTOS.add(new Producto("ACC-001", "Cable HDMI 2 metros", catAccesorios, 150.00, 20));
        PRODUCTOS.add(new Producto("ACC-003", "Adaptador USB-C a HDMI", catAccesorios, 350.00, 12));
        PRODUCTOS.add(new Producto("ACC-004", "Hub USB de 4 puertos", catAccesorios, 290.00, 10));
        PRODUCTOS.add(new Producto("ACC-010", "Soporte ajustable para laptop", catAccesorios, 320.00, 0));

        // 4. Clientes iniciales de prueba (Tomados exactamente de SCR-04 en STKD_MCK_V0_3_291026)
        Cliente c1 = new Cliente("CLI-0001", "Mariana", "López Reyes", 33,
                "2725550142", "mariana.lopez@correo.com", "LORM9203154T3",
                "Mariana López Reyes", TipoCliente.PERSONA_FISICA);

        Cliente c2 = new Cliente("CLI-0002", "Servicios Tecnológicos", "del Valle", 30,
                "2725550199", "compras@stvalle.mx", "STV140612AB9",
                "Servicios Tecnológicos del Valle SA de CV", TipoCliente.PERSONA_MORAL);

        // Cliente sin RFC para probar el bloqueo EX-06 al solicitar factura (Figura 5 de MCK)
        Cliente c3 = new Cliente("CLI-0003", "Carlos", "Hernández Ruiz", 29,
                "2725550177", null, null, null, TipoCliente.PERSONA_FISICA);

        // Cliente Inactivo para probar RN-09 (Figura 7 de MCK)
        Cliente c4 = new Cliente("CLI-0004", "Diana", "Morales Soto", 37,
                "2725550123", "diana.morales@correo.com", "MOSD880920KP1",
                "Diana Morales Soto", TipoCliente.PERSONA_FISICA);
        c4.inactivar();

        Cliente c5 = new Cliente("CLI-0005", "Taller Digital", "Orizaba", 40,
                "2725550166", "contacto@tallerdigital.mx", "TDO190305QX2",
                "Taller Digital Orizaba SA de CV", TipoCliente.PERSONA_MORAL);

        CLIENTES.add(c1);
        CLIENTES.add(c2);
        CLIENTES.add(c3);
        CLIENTES.add(c4);
        CLIENTES.add(c5);
    }
}
