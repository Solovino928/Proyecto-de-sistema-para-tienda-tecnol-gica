package com.stockflow.dao;

import com.stockflow.modelo.Cliente;
import com.stockflow.modelo.Venta;
import java.util.ArrayList;

public interface RepositorioCliente {
    String insertar(Cliente c);
    void actualizar(Cliente c);
    boolean eliminar(String codigo);
    ArrayList<Cliente> listar();
    Cliente buscarCodigo(String codigo);
    Cliente buscarPorRfc(String rfc);
    Cliente buscarPorCorreo(String correo);
    ArrayList<Venta> ventasDe(String codigo);
    int contarVentas(String codigo);
    String previsualizarSiguienteCodigo();
}
