package com.stockflow.dao;

import com.stockflow.modelo.Producto;
import java.util.ArrayList;

public interface RepositorioProducto {
    ArrayList<Producto> listar();
    Producto buscarCodigo(String codigo);
    boolean existeCodigo(String codigo);
    boolean tieneVentas(String codigo);
    boolean insertar(Producto p);
    boolean actualizar(Producto p);
    boolean borrar(String codigo);
    boolean actualizarStock(String codigo, int nuevoStock);
}
