package com.stockflow.controlador;

import com.stockflow.dao.ProductoDAO;
import com.stockflow.dao.RepositorioProducto;
import com.stockflow.modelo.Producto;
import java.text.Normalizer;
import java.util.ArrayList;

public class CatalogoService {
    private RepositorioProducto repositorio;

    public CatalogoService() {
        this.repositorio = new ProductoDAO();
    }

    private String normalizar(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s.trim().toLowerCase(), Normalizer.Form.NFD);
        return n.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
    }

    public ArrayList<Producto> listar() {
        return repositorio.listar();
    }

    public Producto buscarCodigo(String codigo) {
        return repositorio.buscarCodigo(codigo);
    }

    public ArrayList<Producto> buscar(String filtroTexto, String categoriaSeleccionada) {
        ArrayList<Producto> resultado = new ArrayList<>();
        String texto = normalizar(filtroTexto);
        String catFiltro = normalizar(categoriaSeleccionada);

        for (Producto p : repositorio.listar()) {
            boolean coincideTexto = texto.isEmpty()
                    || normalizar(p.getIdentificador()).contains(texto)
                    || normalizar(p.getNombre()).contains(texto);

            boolean coincideCategoria = catFiltro.isEmpty()
                    || catFiltro.equals("todas")
                    || catFiltro.equals("todas las categorias")
                    || normalizar(p.getCategoria().getNombre()).equals(catFiltro);

            if (coincideTexto && coincideCategoria) {
                resultado.add(p);
            }
        }
        return resultado;
    }
}
