/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;
import com.stockflow.dao.ProductoDAO;
import com.stockflow.dao.RepositorioProducto;
import com.stockflow.modelo.Producto;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */

public class CatalogoService {
    private RepositorioProducto repositorio;

    public CatalogoService() {
        this.repositorio = new ProductoDAO();
    }

    public ArrayList<Producto> listar() {
        return repositorio.listar();
    }

    public Producto buscarCodigo(String codigo) {
        return repositorio.buscarCodigo(codigo);
    }

    // Filtra por código o nombre y por categoría (RF-01.2)
    public ArrayList<Producto> buscar(String filtroTexto, String categoriaSeleccionada) {
        ArrayList<Producto> resultado = new ArrayList<>();
        String texto = filtroTexto.trim().toLowerCase();

        for (Producto p : repositorio.listar()) {
            boolean coincideTexto = texto.isEmpty()
                    || p.getIdentificador().toLowerCase().contains(texto)
                    || p.getNombre().toLowerCase().contains(texto);

            boolean coincideCategoria = categoriaSeleccionada.equals("Todas")
                    || p.getCategoria().getNombre().equalsIgnoreCase(categoriaSeleccionada);

            if (coincideTexto && coincideCategoria) {
                resultado.add(p);
            }
        }
        return resultado;
    }
}
