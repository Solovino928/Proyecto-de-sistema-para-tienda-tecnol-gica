package com.stockflow.controlador;

import com.stockflow.dao.ClienteDAO;
import com.stockflow.dao.RepositorioCliente;
import com.stockflow.modelo.Cliente;
import com.stockflow.modelo.ConsolidadoCliente;
import com.stockflow.modelo.EstadoCliente;
import java.text.Normalizer;
import java.util.ArrayList;

public class ClienteService {
    private RepositorioCliente repositorio = new ClienteDAO();
    private ValidadorCliente validador = new ValidadorCliente();

    private String normalizar(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s.trim().toLowerCase(), Normalizer.Form.NFD);
        return n.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
    }

    public String obtenerSiguienteCodigo() {
        return repositorio.previsualizarSiguienteCodigo();
    }

    public ArrayList<Cliente> listarTodos() {
        return repositorio.listar();
    }

    public ArrayList<Cliente> listarActivos() {
        ArrayList<Cliente> activos = new ArrayList<>();
        for (Cliente c : repositorio.listar()) {
            if (c.esActivo()) {
                activos.add(c);
            }
        }
        return activos;
    }

    public Cliente buscarPorCodigo(String codigo) {
        return repositorio.buscarCodigo(codigo);
    }

    // RF-04.3 / EX-05: Devuelve el cliente que ya usa el RFC, excluyendo al propio cliente en edición
    public Cliente buscarConflictoRfc(String rfc, String codigoActual) {
        if (rfc == null || rfc.isBlank()) return null;
        Cliente otro = repositorio.buscarPorRfc(rfc.trim().toUpperCase());
        if (otro != null && !otro.getIdentificador().equalsIgnoreCase(codigoActual != null ? codigoActual : "")) {
            return otro;
        }
        return null;
    }

    public boolean existeRfc(String rfc, String codigoActual) {
        return buscarConflictoRfc(rfc, codigoActual) != null;
    }

    // RF-04.3 / EX-05: Devuelve el cliente que ya usa el correo, excluyendo al propio cliente en edición
    public Cliente buscarConflictoCorreo(String correo, String codigoActual) {
        if (correo == null || correo.isBlank()) return null;
        Cliente otro = repositorio.buscarPorCorreo(correo.trim());
        if (otro != null && !otro.getIdentificador().equalsIgnoreCase(codigoActual != null ? codigoActual : "")) {
            return otro;
        }
        return null;
    }

    public boolean existeCorreo(String correo, String codigoActual) {
        return buscarConflictoCorreo(correo, codigoActual) != null;
    }

    public String registrar(Cliente c) {
        String errorCriticos = validador.validarCriticos(c);
        if (errorCriticos != null) return errorCriticos;

        Cliente dupRfc = buscarConflictoRfc(c.getRfc(), null);
        if (dupRfc != null) {
            return "EX-05: Este RFC ya pertenece al cliente " + dupRfc.getIdentificador() + ".";
        }
        Cliente dupCorreo = buscarConflictoCorreo(c.getCorreo(), null);
        if (dupCorreo != null) {
            return "EX-05: Este correo ya pertenece al cliente " + dupCorreo.getIdentificador() + ".";
        }

        repositorio.insertar(c);
        return null;
    }

    public String actualizar(Cliente c) {
        String errorCriticos = validador.validarCriticos(c);
        if (errorCriticos != null) return errorCriticos;

        Cliente dupRfc = buscarConflictoRfc(c.getRfc(), c.getIdentificador());
        if (dupRfc != null) {
            return "EX-05: Este RFC ya pertenece al cliente " + dupRfc.getIdentificador() + ".";
        }
        Cliente dupCorreo = buscarConflictoCorreo(c.getCorreo(), c.getIdentificador());
        if (dupCorreo != null) {
            return "EX-05: Este correo ya pertenece al cliente " + dupCorreo.getIdentificador() + ".";
        }

        repositorio.actualizar(c);
        return null;
    }

    public void cambiarEstado(String codigo) {
        Cliente c = repositorio.buscarCodigo(codigo);
        if (c != null) {
            if (c.esActivo()) {
                c.inactivar();
            } else {
                c.reactivar();
            }
            repositorio.actualizar(c);
        }
    }

    // RF-04.10 / RN-10 / EX-07: Elimina físicamente si no tiene compras; si tiene, bloquea con EX-07
    public String eliminar(String codigo) {
        int compras = repositorio.contarVentas(codigo);
        if (compras > 0) {
            return "EX-07: El cliente tiene " + compras + " compra(s) registrada(s). "
                    + "Para conservar su historial no puede eliminarse físicamente (RN-10). "
                    + "Puede cambiarlo a Inactivo para impedir su uso en nuevas ventas.";
        }
        boolean borrado = repositorio.eliminar(codigo);
        return borrado ? null : "No se encontró el cliente especificado.";
    }

    // RF-04.7 y RF-04.8: Búsqueda por palabra clave combinada con segmentación por estado y tipo
    public ArrayList<Cliente> buscarYFiltrar(String texto, String estadoFiltro, String tipoFiltro) {
        ArrayList<Cliente> resultado = new ArrayList<>();
        String t = normalizar(texto);
        String est = normalizar(estadoFiltro);
        String tip = normalizar(tipoFiltro);

        for (Cliente c : repositorio.listar()) {
            String telLimpio = c.getTelefono() != null ? c.getTelefono().replaceAll("\\s+", "") : "";
            boolean coincideTexto = t.isEmpty()
                    || normalizar(c.getNombreCompleto()).contains(t)
                    || normalizar(c.getNombreORazonSocial()).contains(t)
                    || normalizar(c.getIdentificador()).contains(t)
                    || telLimpio.contains(t.replaceAll("\\s+", ""));

            boolean coincideEstado = est.isEmpty() || est.equals("todos")
                    || (est.equals("activo") && c.getEstado() == EstadoCliente.ACTIVO)
                    || (est.equals("inactivo") && c.getEstado() == EstadoCliente.INACTIVO);

            boolean coincideTipo = tip.isEmpty() || tip.equals("todos")
                    || normalizar(c.getTipo().getEtiqueta()).contains(tip)
                    || normalizar(c.getTipo().getClaveBD()).contains(tip);

            if (coincideTexto && coincideEstado && coincideTipo) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    public ConsolidadoCliente obtenerConsolidado(String codigo) {
        Cliente c = repositorio.buscarCodigo(codigo);
        if (c == null) return null;
        return new ConsolidadoCliente(c, repositorio.ventasDe(codigo));
    }

    public int contarVentas(String codigo) {
        return repositorio.contarVentas(codigo);
    }
}
