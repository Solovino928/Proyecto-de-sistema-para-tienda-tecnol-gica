package com.stockflow.controlador;

import com.stockflow.modelo.Cliente;
import com.stockflow.modelo.TipoCliente;

public class ValidadorCliente {

    public String validarCriticos(Cliente c) {
        if (c == null) return "EX-04: Datos de cliente inválidos.";
        if (c.getNombre() == null || c.getNombre().trim().isEmpty()) {
            return "EX-04: El nombre del cliente es obligatorio.";
        }
        if (c.getApellido() == null || c.getApellido().trim().isEmpty()) {
            return "EX-04: El apellido del cliente es obligatorio.";
        }
        if (c.getTipo() == null) {
            return "EX-04: Seleccione el tipo de cliente.";
        }
        if (!validarTelefono(c.getTelefono())) {
            return "EX-04: El teléfono es obligatorio y debe tener exactamente 10 dígitos numéricos.";
        }
        if (c.getEdad() != null && (c.getEdad() < 18 || c.getEdad() > 120)) {
            return "EX-04: La edad debe ser un número entero entre 18 y 120 años.";
        }
        if (c.getCorreo() != null && !c.getCorreo().isBlank() && !validarCorreo(c.getCorreo())) {
            return "EX-04: El formato del correo electrónico no es válido.";
        }
        if (c.getRfc() != null && !c.getRfc().isBlank() && !validarRFC(c.getRfc(), c.getTipo())) {
            int longitudEsperada = (c.getTipo() == TipoCliente.PERSONA_FISICA) ? 13 : 12;
            return "EX-04: El RFC para " + c.getTipo().getEtiqueta() + " debe tener " + longitudEsperada + " caracteres alfanuméricos.";
        }
        return null;
    }

    public boolean validarTelefono(String tel) {
        if (tel == null) return false;
        String limpio = tel.replaceAll("\\s+", "");
        return limpio.matches("^[0-9]{10}$");
    }

    public boolean validarCorreo(String correo) {
        if (correo == null || correo.isBlank()) return true;
        return correo.trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    public boolean validarRFC(String rfc, TipoCliente tipo) {
        if (rfc == null || rfc.isBlank()) return true;
        String limpio = rfc.trim().toUpperCase();
        int largo = (tipo == TipoCliente.PERSONA_MORAL) ? 12 : 13;
        return limpio.length() == largo && limpio.matches("^[A-Z0-9Ñ&]+$");
    }
}
