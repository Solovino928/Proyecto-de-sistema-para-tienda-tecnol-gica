package com.stockflow.controlador;

import com.stockflow.dao.ProductoDAO;
import com.stockflow.dao.RepositorioProducto;
import com.stockflow.modelo.Producto;

public class ProductoService {
    private RepositorioProducto repoProducto = new ProductoDAO();
    private InventarioService inventarioService = new InventarioService();

    public String anadirProducto(Producto p) {
        if (p == null) return "EX-08: Datos de producto inválidos.";
        if (p.getCodigo() == null || p.getCodigo().trim().isEmpty()) {
            return "EX-08: El código del producto es obligatorio (RN-14).";
        }
        Producto existente = repoProducto.buscarCodigo(p.getCodigo());
        if (existente != null) {
            return "EX-08: El código " + p.getCodigo().toUpperCase() + " ya existe (" + existente.getNombre() + ").";
        }
        if (p.getNombre() == null || p.getNombre().trim().isEmpty()) {
            return "EX-08: El nombre del producto es obligatorio.";
        }
        if (p.getCategoria() == null) {
            return "EX-08: Seleccione una categoría válida.";
        }
        if (p.getPrecio() <= 0) {
            return "EX-08: El precio debe ser mayor que cero.";
        }
        if (p.getStock() < 0) {
            return "EX-08: La existencia inicial debe ser un entero mayor o igual a cero (RN-18).";
        }
        repoProducto.insertar(p);
        return null;
    }

    public String modificarProducto(Producto p) {
        if (p == null || !repoProducto.existeCodigo(p.getCodigo())) {
            return "Producto no encontrado.";
        }
        if (p.getNombre() == null || p.getNombre().trim().isEmpty()) {
            return "EX-08: El nombre del producto es obligatorio.";
        }
        if (p.getCategoria() == null) {
            return "EX-08: Seleccione una categoría válida.";
        }
        if (p.getPrecio() <= 0) {
            return "EX-08: El precio debe ser mayor que cero.";
        }
        repoProducto.actualizar(p);
        return null;
    }

    // RF-06.3 / RN-16 / EX-09: Bloquea eliminación si el producto forma parte de ventas registradas
    public String eliminarProducto(String codigo) {
        if (repoProducto.tieneVentas(codigo)) {
            return "EX-09: No se puede eliminar el producto " + codigo
                    + " porque forma parte de ventas registradas (RN-16). Puede ajustar su stock a 0.";
        }
        boolean borrado = repoProducto.borrar(codigo);
        return borrado ? null : "No se encontró el producto a eliminar.";
    }

    public String anadirStock(String codigo, int cantidad) {
        return inventarioService.anadirStock(codigo, cantidad);
    }

    public String ajustarStock(String codigo, int nuevoStock, String motivo) {
        return inventarioService.ajustarStock(codigo, nuevoStock, motivo);
    }
}
