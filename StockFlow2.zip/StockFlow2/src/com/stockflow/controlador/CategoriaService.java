package com.stockflow.controlador;

import com.stockflow.dao.CategoriaDAO;
import com.stockflow.dao.RepositorioCategoria;
import com.stockflow.modelo.Categoria;
import java.util.ArrayList;

public class CategoriaService {
    private RepositorioCategoria repoCategoria = new CategoriaDAO();

    public ArrayList<Categoria> listar() {
        return repoCategoria.listar();
    }

    public int contarProductos(int idCategoria) {
        return repoCategoria.contarProductos(idCategoria);
    }

    public String anadirCategoria(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "EX-08: El nombre de la categoría es obligatorio.";
        }
        if (repoCategoria.existeNombre(nombre.trim(), -1)) {
            return "EX-08: Ya existe una categoría con el nombre '" + nombre.trim() + "' (RN-15).";
        }
        repoCategoria.insertar(new Categoria(nombre.trim()));
        return null;
    }

    public String modificarCategoria(int id, String nuevoNombre) {
        if (nuevoNombre == null || nuevoNombre.trim().isEmpty()) {
            return "EX-08: El nombre de la categoría no puede estar vacío.";
        }
        if (repoCategoria.existeNombre(nuevoNombre.trim(), id)) {
            return "EX-08: Ya existe otra categoría con el nombre '" + nuevoNombre.trim() + "' (RN-15).";
        }
        Categoria c = repoCategoria.buscarPorId(id);
        if (c == null) return "Categoría no encontrada.";
        c.setNombre(nuevoNombre.trim());
        repoCategoria.actualizar(c);
        return null;
    }

    // RF-06.6 / RN-17 / EX-09: Bloquea eliminación si tiene productos asociados
    public String eliminarCategoria(int id) {
        int asociados = repoCategoria.contarProductos(id);
        if (asociados > 0) {
            return "EX-09: No se puede eliminar la categoría porque tiene " + asociados
                    + " producto(s) asociado(s) (RN-17).";
        }
        boolean borrada = repoCategoria.borrar(id);
        return borrada ? null : "No se pudo eliminar la categoría.";
    }
}
