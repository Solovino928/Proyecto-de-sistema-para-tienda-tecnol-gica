package com.stockflow.controlador;

import com.stockflow.dao.BaseDatosMemoria;
import com.stockflow.dao.RepositorioVendedor;
import com.stockflow.dao.VendedorDAO;
import com.stockflow.modelo.Vendedor;
import com.stockflow.util.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VendedorService {
    private RepositorioVendedor repositorio = new VendedorDAO();

    public Vendedor obtenerVendedor() {
        return repositorio.obtener();
    }

    public String actualizar(String nombre, String apellido, int edad) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "EX-04: El nombre del vendedor es obligatorio.";
        }
        if (apellido == null || apellido.trim().isEmpty()) {
            return "EX-04: El apellido del vendedor es obligatorio.";
        }
        if (edad < 18 || edad > 120) {
            return "EX-04: La edad del vendedor debe estar entre 18 y 120 años.";
        }
        Vendedor v = repositorio.obtener();
        v.actualizar(nombre.trim(), apellido.trim(), edad);
        repositorio.actualizar(v);
        return null;
    }

    public int contarVentasRegistradas() {
        if (ConexionBD.probarConexion()) {
            String sql = "SELECT COUNT(*) FROM orden WHERE id_vendedor = 1";
            try (Connection conn = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            } catch (Exception e) {
                System.err.println("[Error VendedorService.contarVentasRegistradas]: " + e.getMessage());
            }
        }
        return BaseDatosMemoria.ORDENES.size();
    }
}
