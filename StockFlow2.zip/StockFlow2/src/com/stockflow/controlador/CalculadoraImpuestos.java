package com.stockflow.controlador;

import com.stockflow.modelo.DetalleVenta;
import java.util.ArrayList;

public class CalculadoraImpuestos {

    public double calcularSubtotal(ArrayList<DetalleVenta> detalles) {
        double suma = 0;
        for (DetalleVenta d : detalles) {
            suma += d.calcularImporte();
        }
        return suma;
    }

    public double calcularIVA(double subtotal) {
        return subtotal * 0.16;
    }

    public double calcularTotal(double subtotal, double iva) {
        return subtotal + iva;
    }
}
