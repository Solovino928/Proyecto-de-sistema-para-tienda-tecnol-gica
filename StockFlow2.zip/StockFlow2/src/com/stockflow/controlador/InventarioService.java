package com.stockflow.controlador;

import com.stockflow.dao.MovimientoDAO;
import com.stockflow.dao.ProductoDAO;
import com.stockflow.dao.RepositorioMovimiento;
import com.stockflow.dao.RepositorioProducto;
import com.stockflow.dao.VendedorDAO;
import com.stockflow.modelo.MovimientoInventario;
import com.stockflow.modelo.Producto;
import com.stockflow.modelo.TipoMovimiento;
import java.util.ArrayList;

public class InventarioService {
    private RepositorioProducto repoProducto = new ProductoDAO();
    private RepositorioMovimiento repoMovimiento = new MovimientoDAO();
    private VendedorDAO vendedorDAO = new VendedorDAO();

    // RF-06.7: Entrada de mercancía (suma a la existencia actual)
    public String anadirStock(String codigo, int cantidadEntrada) {
        Producto p = repoProducto.buscarCodigo(codigo);
        if (p == null) return "Producto no encontrado.";
        if (cantidadEntrada <= 0) {
            return "EX-08: La cantidad de entrada debe ser un entero mayor que cero.";
        }
        int anterior = p.getStock();
        int nueva = anterior + cantidadEntrada;
        repoProducto.actualizarStock(codigo, nueva);

        MovimientoInventario mov = new MovimientoInventario(
                repoMovimiento.siguienteId(), p, TipoMovimiento.ENTRADA,
                cantidadEntrada, anterior, nueva, "Entrada de mercancía", vendedorDAO.obtener());
        repoMovimiento.registrar(mov);
        return null;
    }

    // RF-06.8: Ajuste exacto de stock con motivo obligatorio (RN-18)
    public String ajustarStock(String codigo, int nuevaExistencia, String motivo) {
        Producto p = repoProducto.buscarCodigo(codigo);
        if (p == null) return "Producto no encontrado.";
        if (nuevaExistencia < 0) {
            return "EX-08: La existencia nunca puede quedar negativa (RN-18).";
        }
        if (motivo == null || motivo.trim().isEmpty()) {
            return "EX-08: El motivo del ajuste es obligatorio (conteo físico, merma o corrección).";
        }
        int anterior = p.getStock();
        int diferencia = nuevaExistencia - anterior;
        repoProducto.actualizarStock(codigo, nuevaExistencia);

        MovimientoInventario mov = new MovimientoInventario(
                repoMovimiento.siguienteId(), p, TipoMovimiento.AJUSTE,
                diferencia, anterior, nuevaExistencia, motivo.trim(), vendedorDAO.obtener());
        repoMovimiento.registrar(mov);
        return null;
    }

    public ArrayList<MovimientoInventario> listarMovimientos() {
        return repoMovimiento.listarTodos();
    }
}
