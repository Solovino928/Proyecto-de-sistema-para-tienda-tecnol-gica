package com.stockflow.controlador;

import com.stockflow.dao.PersistenciaVenta;
import com.stockflow.dao.VentaDAO;
import com.stockflow.modelo.Cliente;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import com.stockflow.modelo.Vendedor;
import com.stockflow.modelo.Venta;
import java.util.ArrayList;

public class VentaService {
    private ArrayList<DetalleVenta> carrito = new ArrayList<>();
    private PersistenciaVenta persistencia = new VentaDAO();
    private CalculadoraImpuestos calculadora = new CalculadoraImpuestos();
    private VendedorService vendedorService = new VendedorService();

    public ArrayList<DetalleVenta> getCarrito() {
        return carrito;
    }

    public Vendedor obtenerVendedor() {
        return vendedorService.obtenerVendedor();
    }

    public boolean validarStock(Producto p, int cantidad) {
        return p != null && cantidad > 0 && p.hayStock(cantidad);
    }

    public String agregarAlCarrito(Producto p, int cantidad) {
        if (p == null) return "Seleccione un producto.";
        if (cantidad <= 0) return "La cantidad debe ser mayor a cero (RN-01).";

        DetalleVenta existente = null;
        for (DetalleVenta d : carrito) {
            if (d.getProducto().getIdentificador().equals(p.getIdentificador())) {
                existente = d;
                break;
            }
        }

        int totalSolicitado = cantidad + (existente != null ? existente.getCantidad() : 0);
        if (!validarStock(p, totalSolicitado)) {
            return "EX-01: Stock insuficiente. Disponible: " + p.getStock();
        }

        if (existente != null) {
            existente.actualizarCantidad(totalSolicitado);
        } else {
            carrito.add(new DetalleVenta(p, cantidad));
        }
        return null;
    }

    public void quitarDelCarrito(int fila) {
        if (fila >= 0 && fila < carrito.size()) {
            carrito.remove(fila);
        }
    }

    public void limpiarCarrito() {
        carrito.clear();
    }

    public double obtenerSubtotal() {
        return calculadora.calcularSubtotal(carrito);
    }

    public double obtenerIVA() {
        return calculadora.calcularIVA(obtenerSubtotal());
    }

    public double obtenerTotal() {
        return calculadora.calcularTotal(obtenerSubtotal(), obtenerIVA());
    }

    // RF-03.1 / RN-12 / EX-06: Valida que el cliente esté activo y tenga datos fiscales completos si requiere factura
    public String validarFactura(Venta v) {
        if (!v.isRequiereFactura()) return null;
        Cliente c = v.getCliente();
        if (c == null) {
            return "EX-06: Se solicitó factura pero no se eligió cliente. Seleccione un cliente activo.";
        }
        if (!c.esActivo()) {
            return "EX-06: El cliente seleccionado está Inactivo (RN-09).";
        }
        if (c.getRfc() == null || c.getRfc().isBlank()) {
            return "EX-06: El cliente " + c.getIdentificador() + " no tiene RFC capturado. Complete los datos fiscales.";
        }
        if (c.getRazonSocial() == null || c.getRazonSocial().isBlank()) {
            return "EX-06: El cliente " + c.getIdentificador() + " no tiene Razón Social capturada.";
        }
        if (c.getCorreo() == null || c.getCorreo().isBlank()) {
            return "EX-06: El cliente " + c.getIdentificador() + " no tiene Correo Electrónico capturado.";
        }
        return null;
    }

    public boolean procesarVenta(Venta venta) {
        if (carrito.isEmpty()) return false;
        boolean exito = persistencia.registrarVenta(venta);
        if (exito) {
            limpiarCarrito();
        }
        return exito;
    }
}
