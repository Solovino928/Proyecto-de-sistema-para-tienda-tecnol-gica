/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import java.util.ArrayList; 
/**
 *
 * @author adrianzsanchezalducin
 */

public class VentaService {
    private ArrayList<DetalleVenta> carrito = new ArrayList<>();
    private CalculadoraImpuestos calculadora = new CalculadoraImpuestos();

    public ArrayList<DetalleVenta> getCarrito() {
        return carrito;
    }

    public boolean validarStock(Producto p, int cantidad) {
        return p != null && cantidad > 0 && p.hayStock(cantidad);
    }

    // Avance de Iteración 2: Agrega al carrito validando stock disponible (RF-02.1, EX-01)
    public String agregarAlCarrito(Producto p, int cantidad) {
        if (p == null) return "Seleccione un producto.";
        if (cantidad <= 0) return "La cantidad debe ser mayor a cero (RN-01).";

        DetalleVenta existente = null;
        for (DetalleVenta d : carrito) {
            if (d.getProducto().getIdentificador().equals(p.getIdentificador())) {
                existente = d;
                break;
            }
        }

        int totalSolicitado = cantidad + (existente != null ? existente.getCantidad() : 0);
        if (!validarStock(p, totalSolicitado)) {
            return "EX-01: Stock insuficiente. Disponible: " + p.getStock();
        }

        if (existente != null) {
            existente.actualizarCantidad(totalSolicitado);
        } else {
            carrito.add(new DetalleVenta(p, cantidad));
        }
        return null;
    }

    public void quitarDelCarrito(int fila) {
        if (fila >= 0 && fila < carrito.size()) {
            carrito.remove(fila);
        }
    }

    public void limpiarCarrito() {
        carrito.clear();
    }

    public double obtenerSubtotal() {
        return calculadora.calcularSubtotal(carrito);
    }

    public double obtenerIVA() {
        return calculadora.calcularIVA(obtenerSubtotal());
    }

    public double obtenerTotal() {
        return calculadora.calcularTotal(obtenerSubtotal(), obtenerIVA());
    }
}