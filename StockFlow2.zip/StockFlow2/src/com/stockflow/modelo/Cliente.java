package com.stockflow.modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Cliente extends Entidad {
    private String nombre;
    private String apellido;
    private Integer edad;
    private String telefono;
    private String correo;
    private String rfc;
    private String razonSocial;
    private TipoCliente tipo;
    private EstadoCliente estado;
    private LocalDateTime fechaRegistro;
    private LocalDateTime fechaModificacion;

    public Cliente(String codigo, String nombre, String apellido, Integer edad,
                   String telefono, String correo, String rfc, String razonSocial,
                   TipoCliente tipo) {
        super(codigo);
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.telefono = telefono;
        this.correo = (correo == null || correo.isBlank()) ? null : correo.trim();
        this.rfc = (rfc == null || rfc.isBlank()) ? null : rfc.trim().toUpperCase();
        this.razonSocial = (razonSocial == null || razonSocial.isBlank()) ? null : razonSocial.trim();
        this.tipo = tipo;
        this.estado = EstadoCliente.ACTIVO;
        this.fechaRegistro = LocalDateTime.now();
        this.fechaModificacion = LocalDateTime.now();
    }

    public String getCodigo() { return identificador; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; registrarModificacion(); }
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; registrarModificacion(); }
    public Integer getEdad() { return edad; }
    public void setEdad(Integer edad) { this.edad = edad; registrarModificacion(); }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; registrarModificacion(); }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) {
        this.correo = (correo == null || correo.isBlank()) ? null : correo.trim();
        registrarModificacion();
    }
    public String getRfc() { return rfc; }
    public void setRfc(String rfc) {
        this.rfc = (rfc == null || rfc.isBlank()) ? null : rfc.trim().toUpperCase();
        registrarModificacion();
    }
    public String getRazonSocial() { return razonSocial; }
    public void setRazonSocial(String razonSocial) {
        this.razonSocial = (razonSocial == null || razonSocial.isBlank()) ? null : razonSocial.trim();
        registrarModificacion();
    }
    public TipoCliente getTipo() { return tipo; }
    public void setTipo(TipoCliente tipo) { this.tipo = tipo; registrarModificacion(); }
    public EstadoCliente getEstado() { return estado; }
    public void setEstado(EstadoCliente estado) { this.estado = estado; }
    
    // Setters indispensables para que el DAO pueda asignar las fechas desde la BD
    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }
    
    public LocalDateTime getFechaModificacion() { return fechaModificacion; }
    public void setFechaModificacion(LocalDateTime fechaModificacion) { this.fechaModificacion = fechaModificacion; }

    public String getFechaRegistroFormateada() {
        return fechaRegistro != null ? fechaRegistro.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm")) : "—";
    }

    public String getFechaModificacionFormateada() {
        return fechaModificacion != null
                ? fechaModificacion.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm"))
                : "—";
    }

    public String getNombreCompleto() {
        return (nombre + " " + apellido).trim();
    }

    public String getNombreORazonSocial() {
        if (tipo == TipoCliente.PERSONA_MORAL && razonSocial != null && !razonSocial.isBlank()) {
            return razonSocial;
        }
        return getNombreCompleto();
    }

    public boolean esActivo() {
        return this.estado == EstadoCliente.ACTIVO;
    }

    public boolean tieneDatosFiscales() {
        return rfc != null && !rfc.isBlank()
                && razonSocial != null && !razonSocial.isBlank()
                && correo != null && !correo.isBlank();
    }

    public void inactivar() {
        this.estado = EstadoCliente.INACTIVO;
        registrarModificacion();
    }

    public void reactivar() {
        this.estado = EstadoCliente.ACTIVO;
        registrarModificacion();
    }

    public void registrarModificacion() {
        this.fechaModificacion = LocalDateTime.now();
    }

    @Override
    public String mostrarResumen() {
        return getNombreCompleto() + " (" + identificador + ")";
    }

    @Override
    public String toString() {
        return getNombreCompleto() + " (" + identificador + ")";
    }
}