package com.stockflow.modelo;

public enum TipoCliente {
    PERSONA_FISICA("Persona Física", "FISICA"),
    PERSONA_MORAL("Persona Moral", "MORAL");

    private final String etiqueta;
    private final String claveBD;

    TipoCliente(String etiqueta, String claveBD) {
        this.etiqueta = etiqueta;
        this.claveBD = claveBD;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public String getClaveBD() {
        return claveBD;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
