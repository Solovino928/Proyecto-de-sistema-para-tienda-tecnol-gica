package com.stockflow.modelo;

/**
 * Interfaz para elementos que calculan su propio importe monetario.
 */
public interface Calculable {
    double calcularImporte();
}
