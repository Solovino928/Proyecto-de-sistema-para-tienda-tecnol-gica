package com.stockflow.modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Vendedor extends Entidad {
    private String nombre;
    private String apellido;
    private int edad;
    private LocalDateTime fechaModificacion;

    public Vendedor(String id, String nombre, String apellido, int edad) {
        super(id);
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.fechaModificacion = LocalDateTime.now();
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public LocalDateTime getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(LocalDateTime fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    public String getFechaModificacionFormateada() {
        return fechaModificacion != null
                ? fechaModificacion.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm"))
                : "—";
    }

    public String nombreCompleto() {
        return nombre + " " + apellido;
    }

    public void actualizar(String nuevoNombre, String nuevoApellido, int nuevaEdad) {
        this.nombre = nuevoNombre;
        this.apellido = nuevoApellido;
        this.edad = nuevaEdad;
        this.fechaModificacion = LocalDateTime.now(); // RN-13
    }

    @Override
    public String mostrarResumen() {
        return nombreCompleto() + " (" + edad + " años)";
    }
}
