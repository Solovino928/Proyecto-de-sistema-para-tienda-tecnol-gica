package com.stockflow.modelo;

public class DetalleVenta implements Calculable {
    private Producto producto;
    private int cantidad;
    private double precioUnitario;

    public DetalleVenta(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
        // Congela el precio unitario vigente al momento de agregar al carrito (RN-03, RN-19)
        this.precioUnitario = producto.getPrecio();
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void actualizarCantidad(int nuevaCantidad) {
        this.cantidad = nuevaCantidad;
    }

    @Override
    public double calcularImporte() {
        return precioUnitario * cantidad;
    }
}
