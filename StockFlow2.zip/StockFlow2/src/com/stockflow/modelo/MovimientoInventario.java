package com.stockflow.modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MovimientoInventario extends Entidad {
    private int id;
    private Producto producto;
    private TipoMovimiento tipo;
    private int cantidad;
    private int existenciaAnterior;
    private int existenciaNueva;
    private String motivo;
    private LocalDateTime fecha;
    private Vendedor vendedor;

    public MovimientoInventario(int id, Producto producto, TipoMovimiento tipo, int cantidad,
                                int existenciaAnterior, int existenciaNueva, String motivo, Vendedor vendedor) {
        super("MOV-" + String.format("%04d", id));
        this.id = id;
        this.producto = producto;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.existenciaAnterior = existenciaAnterior;
        this.existenciaNueva = existenciaNueva;
        this.motivo = motivo;
        this.fecha = LocalDateTime.now();
        this.vendedor = vendedor;
    }

    public int getId() { return id; }
    public Producto getProducto() { return producto; }
    public TipoMovimiento getTipo() { return tipo; }
    public int getCantidad() { return cantidad; }
    public int getExistenciaAnterior() { return existenciaAnterior; }
    public int getExistenciaNueva() { return existenciaNueva; }
    public String getMotivo() { return motivo; }
    
    public LocalDateTime getFecha() { return fecha; }
    // Setter indispensable para que el DAO asigne la fecha exacta de PostgreSQL
    public void setFecha(LocalDateTime fecha) { 
        if (fecha != null) {
            this.fecha = fecha; 
        }
    }
    
    public Vendedor getVendedor() { return vendedor; }

    public String getFechaFormateada() {
        return fecha != null ? fecha.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm")) : "—";
    }

    @Override
    public String mostrarResumen() {
        return "[" + getFechaFormateada() + "] " + tipo + " · " + producto.getCodigo()
                + " (" + existenciaAnterior + " -> " + existenciaNueva + ") "
                + (motivo != null ? "Motivo: " + motivo : "");
    }
}
