package com.stockflow.modelo;

/**
 * Superclase abstracta del modelo de dominio (STKD_ARQ_V0_3 - Figura 6).
 */
public abstract class Entidad {
    protected String identificador;

    public Entidad(String identificador) {
        this.identificador = identificador;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public abstract String mostrarResumen();
}
