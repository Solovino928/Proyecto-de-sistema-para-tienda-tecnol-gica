/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;

/**
 *
 * @author adrianzsanchezalducin
 */

public class Producto extends Entidad {
    private String nombre;
    private Categoria categoria;
    private double precio;
    private int stock;

    public Producto(String codigo, String nombre, Categoria categoria, double precio, int stock) {
        super(codigo); // Envía el código a la clase abstracta Entidad
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }

    public String getNombre() { 
        return nombre; 
    }
    public Categoria getCategoria() { 
        return categoria; 
    }
    public double getPrecio() { 
        return precio; 
    }
    public int getStock() { 
        return stock; 
    }

    public boolean hayStock(int cantidad) {
        return this.stock >= cantidad;
    }

    public void descontarStock(int cantidad) {
        if (hayStock(cantidad)) {
            this.stock -= cantidad;
        }
    }

    @Override
    public String mostrarResumen() {
        return identificador + " - " + nombre + " ($" + precio + ")";
    }
}