package com.stockflow.modelo;

public class Producto extends Entidad {
    private String nombre;
    private Categoria categoria;
    private double precio;
    private int stock;

    public Producto(String codigo, String nombre, Categoria categoria, double precio, int stock) {
        super(codigo != null ? codigo.trim().toUpperCase() : "");
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }

    public String getCodigo() {
        return identificador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        if (stock >= 0) {
            this.stock = stock;
        }
    }

    public boolean hayStock(int cantidad) {
        return cantidad > 0 && this.stock >= cantidad;
    }

    public void descontarStock(int cantidad) {
        if (hayStock(cantidad)) {
            this.stock -= cantidad;
        }
    }

    @Override
    public String mostrarResumen() {
        return identificador + " · " + nombre + " ($" + String.format("%.2f", precio) + ")";
    }

    @Override
    public String toString() {
        return identificador + " - " + nombre;
    }
}
