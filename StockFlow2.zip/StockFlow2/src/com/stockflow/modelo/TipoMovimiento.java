package com.stockflow.modelo;

public enum TipoMovimiento {
    ENTRADA("Entrada"),
    AJUSTE("Ajuste");

    private final String etiqueta;

    TipoMovimiento(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
