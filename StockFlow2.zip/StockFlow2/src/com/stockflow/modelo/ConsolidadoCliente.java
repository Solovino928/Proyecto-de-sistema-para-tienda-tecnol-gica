package com.stockflow.modelo;

import java.util.ArrayList;

public class ConsolidadoCliente {
    private final Cliente cliente;
    private final ArrayList<Venta> compras;
    private final int numeroCompras;
    private final double montoTotalAcumulado;
    private final String fechaUltimaCompra;

    public ConsolidadoCliente(Cliente cliente, ArrayList<Venta> compras) {
        this.cliente = cliente;
        this.compras = compras;
        this.numeroCompras = compras.size();
        double suma = 0;
        for (Venta v : compras) {
            suma += v.getTotal();
        }
        this.montoTotalAcumulado = suma;
        this.fechaUltimaCompra = compras.isEmpty() ? "Sin compras registradas" : compras.get(0).getFechaFormateada();
    }

    public Cliente getCliente() { return cliente; }
    public ArrayList<Venta> getCompras() { return compras; }
    public int getNumeroCompras() { return numeroCompras; }
    public double getMontoTotalAcumulado() { return montoTotalAcumulado; }
    public String getFechaUltimaCompra() { return fechaUltimaCompra; }
}
