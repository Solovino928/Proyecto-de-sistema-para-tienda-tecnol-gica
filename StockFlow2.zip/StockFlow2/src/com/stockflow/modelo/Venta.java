package com.stockflow.modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Venta extends Entidad implements Calculable {
    private LocalDateTime fecha;
    private Vendedor vendedor;
    private Cliente cliente;
    private boolean requiereFactura;
    private ArrayList<DetalleVenta> detalles;
    private double subtotal;
    private double iva;
    private double total;

    public Venta(String folio, Vendedor vendedor, Cliente cliente, boolean requiereFactura,
                 ArrayList<DetalleVenta> detalles, double subtotal, double iva, double total) {
        super(folio);
        this.fecha = LocalDateTime.now();
        this.vendedor = vendedor;
        this.cliente = cliente;
        this.requiereFactura = requiereFactura;
        this.detalles = detalles != null ? new ArrayList<>(detalles) : new ArrayList<>();
        this.subtotal = subtotal;
        this.iva = iva;
        this.total = total;
    }

    public String getFolio() { return identificador; }
    public void setFolio(String folio) { this.identificador = folio; }
    
    public LocalDateTime getFecha() { return fecha; }
    // Setter indispensable para que el DAO asigne la fecha de la base de datos
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
    
    public String getFechaFormateada() {
        return fecha != null ? fecha.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm")) : "—";
    }
    public Vendedor getVendedor() { return vendedor; }
    public void setVendedor(Vendedor vendedor) { this.vendedor = vendedor; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public boolean isRequiereFactura() { return requiereFactura; }
    public void setRequiereFactura(boolean requiereFactura) { this.requiereFactura = requiereFactura; }
    public ArrayList<DetalleVenta> getDetalles() { return detalles; }
    public double getSubtotal() { return subtotal; }
    public double getIva() { return iva; }
    public double getTotal() { return total; }

    public void agregarDetalle(DetalleVenta d) {
        this.detalles.add(d);
    }

    public double calcularSubtotal() {
        return subtotal;
    }

    @Override
    public double calcularImporte() {
        return total;
    }

    @Override
    public String mostrarResumen() {
        String nomCliente = (cliente != null) ? cliente.mostrarResumen() : "Público en general";
        return "Folio: " + identificador + " | Cliente: " + nomCliente + " | Total: $" + String.format("%.2f", total);
    }
}
