/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.dao;

import com.stockflow.modelo.Categoria;
import com.stockflow.modelo.Producto;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */

public class ProductoDAO implements RepositorioProducto {
    private static ArrayList<Producto> catalogoMemoria = new ArrayList<>();

    static {
        // Inicializar con los 10 productos oficiales del documento de diseño SCR-01
        if (catalogoMemoria.isEmpty()) {
            catalogoMemoria.add(new Producto("PER-001", "Teclado mecánico RGB", new Categoria("Periféricos"), 850.00, 12));
            catalogoMemoria.add(new Producto("PER-003", "Mouse inalámbrico", new Categoria("Periféricos"), 250.00, 20));
            catalogoMemoria.add(new Producto("PER-007", "Cámara web Full HD", new Categoria("Periféricos"), 720.00, 6));
            catalogoMemoria.add(new Producto("ALM-002", "Memoria USB 64 GB", new Categoria("Almacenamiento"), 180.00, 25));
            catalogoMemoria.add(new Producto("ALM-007", "SSD SATA 480 GB", new Categoria("Almacenamiento"), 690.00, 8));
            catalogoMemoria.add(new Producto("ALM-009", "Disco duro externo 1 TB", new Categoria("Almacenamiento"), 1250.00, 5));
            catalogoMemoria.add(new Producto("ACC-001", "Cable HDMI 2 metros", new Categoria("Accesorios y conectividad"), 150.00, 20));
            catalogoMemoria.add(new Producto("ACC-003", "Adaptador USB-C a HDMI", new Categoria("Accesorios y conectividad"), 350.00, 12));
            catalogoMemoria.add(new Producto("ACC-004", "Hub USB de 4 puertos", new Categoria("Accesorios y conectividad"), 290.00, 10));
            catalogoMemoria.add(new Producto("ACC-010", "Soporte ajustable para laptop", new Categoria("Accesorios y conectividad"), 320.00, 0));
        }
    }

    @Override
    public ArrayList<Producto> listar() {
        return catalogoMemoria;
    }

    @Override
    public ArrayList<Producto> buscar(String codigoNombre, String categoriaFiltro) {
        ArrayList<Producto> resultado = new ArrayList<>();
        String filtro = codigoNombre == null ? "" : codigoNombre.trim().toLowerCase();

        for (Producto p : catalogoMemoria) {
            boolean coincideTexto = filtro.isEmpty()
                    || p.getCodigo().toLowerCase().contains(filtro)
                    || p.getNombre().toLowerCase().contains(filtro);
            boolean coincideCat = categoriaFiltro == null
                    || categoriaFiltro.equals("Todas")
                    || p.getCategoria().getNombre().equalsIgnoreCase(categoriaFiltro);

            if (coincideTexto && coincideCat) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public Producto buscarPorCodigoExacto(String codigo) {
        for (Producto p : catalogoMemoria) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        }
        return null;
    }
}