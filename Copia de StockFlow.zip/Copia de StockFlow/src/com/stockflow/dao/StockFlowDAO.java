/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.dao;

import com.stockflow.modelo.Categoria;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class StockFlowDAO {
    private static final String ARCHIVO_INVENTARIO = "stockflow_inventario.txt";
    private static final String ARCHIVO_VENTAS = "stockflow_ventas.txt";
    private List<Producto> catalogo = new ArrayList<>();
    private int contadorFolio = 0;

    public StockFlowDAO() {
        cargarInventarioLocal();
        cargarUltimoFolio();
    }

    // Carga el catálogo desde el archivo local o inicializa los datos por defecto
    private void cargarInventarioLocal() {
        File archivo = new File(ARCHIVO_INVENTARIO);
        if (archivo.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    String[] p = linea.split("\\|");
                    // p[0]: código, p[1]: nombre, p[2]: categoría, p[3]: precio, p[4]: existencia
                    catalogo.add(new Producto(
                        p[0], 
                        p[1], 
                        new Categoria(p[2]), 
                        Double.parseDouble(p[3]), 
                        Integer.parseInt(p[4])
                    ));
                }
                return;
            } catch (Exception e) {
                catalogo.clear();
            }
        }
        
        // Catálogo oficial inicial (SCR-01)
        catalogo.add(new Producto("PER-001", "Teclado mecánico RGB", new Categoria("Periféricos"), 850.00, 12));
        catalogo.add(new Producto("PER-003", "Mouse inalámbrico", new Categoria("Periféricos"), 250.00, 20));
        catalogo.add(new Producto("PER-007", "Cámara web Full HD", new Categoria("Periféricos"), 720.00, 6));
        catalogo.add(new Producto("ALM-002", "Memoria USB 64 GB", new Categoria("Almacenamiento"), 180.00, 25));
        catalogo.add(new Producto("ALM-007", "SSD SATA 480 GB", new Categoria("Almacenamiento"), 690.00, 8));
        catalogo.add(new Producto("ALM-009", "Disco duro externo 1 TB", new Categoria("Almacenamiento"), 1250.00, 5));
        catalogo.add(new Producto("ACC-001", "Cable HDMI 2 metros", new Categoria("Accesorios y conectividad"), 150.00, 20));
        catalogo.add(new Producto("ACC-003", "Adaptador USB-C a HDMI", new Categoria("Accesorios y conectividad"), 350.00, 12));
        catalogo.add(new Producto("ACC-004", "Hub USB de 4 puertos", new Categoria("Accesorios y conectividad"), 290.00, 10));
        catalogo.add(new Producto("ACC-010", "Soporte ajustable para laptop", new Categoria("Accesorios y conectividad"), 320.00, 0));
        guardarInventarioEnDisco();
    }

    private void guardarInventarioEnDisco() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARCHIVO_INVENTARIO))) {
            for (Producto p : catalogo) {
                pw.println(p.getCodigo() + "|" + p.getNombre() + "|" + p.getCategoria().getNombre() + "|"
                        + p.getPrecioVenta() + "|" + p.getExistencia());
            }
        } catch (IOException e) {
            throw new RuntimeException("Error al guardar inventario local (EX-03).");
        }
    }

    private void cargarUltimoFolio() {
        File archivo = new File(ARCHIVO_VENTAS);
        if (!archivo.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            while (br.readLine() != null) {
                contadorFolio++;
            }
        } catch (IOException ignored) {}
    }

    public List<Producto> obtenerTodos() {
        return catalogo;
    }

    public Producto buscarPorCodigo(String codigo) {
        for (Producto p : catalogo) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        }
        return null;
    }

    // Filtra por código/nombre y categoría (RF-01.2)
    public List<Producto> filtrarProductos(String texto, String categoria) {
        List<Producto> resultado = new ArrayList<>();
        String filtro = texto.trim().toLowerCase();
        for (Producto p : catalogo) {
            boolean coincideTexto = filtro.isEmpty()
                    || p.getCodigo().toLowerCase().contains(filtro)
                    || p.getNombre().toLowerCase().contains(filtro);
            boolean coincideCat = categoria.equals("Todas")
                    || p.getCategoria().getNombre().equalsIgnoreCase(categoria);
            if (coincideTexto && coincideCat) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    // Transacción atómica: Guarda la venta, descuenta stock y retorna el folio único (RF-03.2, RF-03.3, RNF-03)
    public String registrarVentaAtomica(List<DetalleVenta> partidas, double total) throws Exception {
        for (DetalleVenta d : partidas) {
            if (!d.getProducto().hayStock(d.getCantidad())) {
                throw new Exception("Stock insuficiente para " + d.getProducto().getNombre());
            }
        }

        // 2. Generar folio único consecutivo
        int siguienteNumero = contadorFolio + 1;
        String folio = String.format("STKD-2026-%04d", siguienteNumero);
        String fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss"));

        // 3. Guardar registro y actualizar
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARCHIVO_VENTAS, true))) {
            pw.println(folio + "|" + fecha + "|" + String.format("%.2f", total));
            for (DetalleVenta d : partidas) {
                Producto prod = d.getProducto();
                prod.descontarStock(d.getCantidad()); // Descuenta usando el método oficial del diagrama
            }
            guardarInventarioEnDisco();
            contadorFolio = siguienteNumero;
            return folio;
        } catch (Exception ex) {
            throw new Exception("EX-03: Fallo al guardar en la base local. No se descontó inventario.");
        }
    }
}