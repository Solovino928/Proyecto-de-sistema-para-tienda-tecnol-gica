/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.dao;
import com.stockflow.modelo.Producto;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */


public interface RepositorioProducto {
    ArrayList<Producto> listar();
    ArrayList<Producto> buscar(String codigoNombre, String categoriaFiltro);
}