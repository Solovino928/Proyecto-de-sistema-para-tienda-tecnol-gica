/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;
import com.stockflow.modelo.DetalleVenta;
import java.util.List;
/**
 *
 * @author adrianzsanchezalducin
 */

public class CalculadoraImpuestos {

    public double calcularSubtotal(List<DetalleVenta> detalles) {
        double totalConIVA = 0;
        for (DetalleVenta d : detalles) {
            totalConIVA += d.calcularImporte();
        }
        return totalConIVA / 1.16;
    }

    public double calcularIVA(double subtotal) {
        return subtotal * 0.16;
    }

    public double calcularTotal(double subtotal, double iva) {
        return subtotal + iva;
    }
}