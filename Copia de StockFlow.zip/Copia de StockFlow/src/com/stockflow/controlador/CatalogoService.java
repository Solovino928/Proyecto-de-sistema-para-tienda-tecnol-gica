/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;
import com.stockflow.dao.ProductoDAO;
import com.stockflow.modelo.Producto;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */

public class CatalogoService {
    private ProductoDAO productoDAO = new ProductoDAO();

    public ArrayList<Producto> listarProductos() {
        return productoDAO.listar();
    }

    public ArrayList<Producto> buscarProductos(String texto, String categoria) {
        return productoDAO.buscar(texto, categoria);
    }
}
