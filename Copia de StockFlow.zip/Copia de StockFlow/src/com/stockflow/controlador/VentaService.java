/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;

import com.stockflow.dao.StockFlowDAO;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author adrianzsanchezalducin
 */
public class VentaService {
    private StockFlowDAO dao;
    private List<DetalleVenta> carrito = new ArrayList<>();
    private CalculadoraImpuestos calculadora = new CalculadoraImpuestos();

    public VentaService(StockFlowDAO dao) {
        this.dao = dao;
    }

    public List<DetalleVenta> getCarrito() {
        return carrito;
    }

    // Agrega o actualiza un artículo en la lista validando stock (RF-02.1 / EX-01)
    public String agregarArticulo(Producto producto, int cantidadSolicitada) {
        if (producto == null) {
            return "Seleccione un producto del catálogo.";
        }
        if (cantidadSolicitada <= 0) {
            return "RN-01: La cantidad debe ser un número entero mayor que cero.";
        }

        // Revisar si el producto ya está en el carrito para sumar cantidades
        DetalleVenta existente = null;
        for (DetalleVenta d : carrito) {
            if (d.getProducto().getCodigo().equals(producto.getCodigo())) {
                existente = d;
                break;
            }
        }

        int cantidadTotal = cantidadSolicitada + (existente != null ? existente.getCantidad() : 0);
        
        // Usamos getExistencia() adaptado al nuevo diagrama de clases
        if (cantidadTotal > producto.getExistencia()) {
            return "EX-01: Existencia insuficiente. Solo hay " + producto.getExistencia() + " unidades disponibles.";
        }

        if (existente != null) {
            existente.setCantidad(cantidadTotal);
        } else {
            carrito.add(new DetalleVenta(producto, cantidadSolicitada));
        }
        return null; // null significa sin errores
    }

    // Permite retirar una partida de la lista (RF-02.2)
    public void eliminarPartida(int indice) {
        if (indice >= 0 && indice < carrito.size()) {
            carrito.remove(indice);
        }
    }

    public void limpiarCarrito() {
        carrito.clear();
    }

    // Cálculos delegados a CalculadoraImpuestos (RF-02.2)
    public double calcularTotal() {
        double sub = calculadora.calcularSubtotal(carrito);
        double iva = calculadora.calcularIVA(sub);
        return calculadora.calcularTotal(sub, iva);
    }

    public double calcularSubtotalSinIVA() {
        return calculadora.calcularSubtotal(carrito);
    }

    public double calcularIVA() {
        return calculadora.calcularIVA(calcularSubtotalSinIVA());
    }

    // Procesa el cierre de venta validando RN-04 (RF-03.1, RF-03.2, RF-03.3)
    public String confirmarYRegistrarVenta() throws Exception {
        if (carrito.isEmpty()) {
            throw new Exception("RN-04: La lista de venta está vacía. Agregue al menos un producto.");
        }
        String folio = dao.registrarVentaAtomica(carrito, calcularTotal());
        limpiarCarrito();
        return folio;
    }
}