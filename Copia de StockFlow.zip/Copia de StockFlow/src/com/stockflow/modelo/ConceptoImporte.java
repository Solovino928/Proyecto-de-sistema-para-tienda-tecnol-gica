/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;

/**
 *
 * @author adrianzsanchezalducin
 */
public abstract class ConceptoImporte implements Calculable {
    @Override
    public abstract double calcularImporte();
}
