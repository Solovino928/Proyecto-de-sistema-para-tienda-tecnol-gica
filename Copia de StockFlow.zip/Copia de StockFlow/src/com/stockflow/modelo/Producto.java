/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;

/**
 *
 * @author adrianzsanchezalducin
 */

public class Producto {
    private String codigo;
    private String nombre;
    private Categoria categoria;
    private double precioVenta;
    private int existencia;

    public Producto(String codigo, String nombre, Categoria categoria, double precioVenta, int existencia) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precioVenta = precioVenta;
        this.existencia = existencia;
    }

    public String getCodigo() { 
        return codigo;
    }
    public String getNombre() {
        return nombre; 
    }
    public Categoria getCategoria() { 
        return categoria; 
    }
    public double getPrecioVenta() { 
        return precioVenta; 
    }
    public int getExistencia() { 
        return existencia; 
    }
    public void setExistencia(int existencia) { 
        this.existencia = existencia;
    }

    public boolean hayStock(int cantidad) {
        return this.existencia >= cantidad;
    }

    public void descontarStock(int cantidad) {
        if (hayStock(cantidad)) {
            this.existencia -= cantidad;
        }
    }
}