/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;

/**
 *
 * @author adrianzsanchezalducin
 */

public class DetalleVenta extends ConceptoImporte {
    private Producto producto;
    private int cantidad;
    private double precioUnitario;

    public DetalleVenta(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = producto.getPrecioVenta();
    }

    public Producto getProducto() {
        return producto; 
    }
    public int getCantidad() { 
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public double getPrecioUnitario() { 
        return precioUnitario; 
    }

    @Override
    public double calcularImporte() {
        return this.precioUnitario * this.cantidad;
    }
}