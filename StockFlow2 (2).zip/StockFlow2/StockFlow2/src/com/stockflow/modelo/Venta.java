/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author alduc
 */


public class Venta extends Entidad implements Calculable {
    private LocalDateTime fecha;
    private Vendedor vendedor;
    private Cliente cliente; // null equivale a "Público en general" (RN-07)
    private boolean requiereFactura;
    private ArrayList<DetalleVenta> detalles;
    private double subtotal;
    private double iva;
    private double total;

    public Venta(String folio, Vendedor vendedor, Cliente cliente, boolean requiereFactura,
                 ArrayList<DetalleVenta> detalles, double subtotal, double iva, double total) {
        super(folio);
        this.fecha = LocalDateTime.now();
        this.vendedor = vendedor;
        this.cliente = cliente;
        this.requiereFactura = requiereFactura;
        this.detalles = new ArrayList<>(detalles);
        this.subtotal = subtotal;
        this.iva = iva;
        this.total = total;
    }

    public void setFolio(String folio) {
        this.identificador = folio;
    }
    public LocalDateTime getFecha() { 
        return fecha; 
    }
    public Vendedor getVendedor() {
        return vendedor; 
    }
    public Cliente getCliente() {
        return cliente;
    }
    public boolean isRequiereFactura() { 
        return requiereFactura;
    }
    public ArrayList<DetalleVenta> getDetalles() {
        return detalles; 
    }
    public double getSubtotal() {
        return subtotal; 
    }
    public double getIva() { 
        return iva;
    }
    public double getTotal() {
        return total; 
    }

    public void agregarDetalle(DetalleVenta d) {
        this.detalles.add(d);
    }

    public double calcularSubtotal() {
        return subtotal;
    }

    @Override
    public double calcularImporte() {
        return total;
    }

    @Override
    public String mostrarResumen() {
        String textoCliente = (cliente != null) ? cliente.mostrarResumen() : "Público en general";
        return "Folio: " + identificador + " | Vendedor: " + vendedor.nombreCompleto()
                + " | Cliente: " + textoCliente + " | Total: $" + String.format("%.2f", total);
    }
}