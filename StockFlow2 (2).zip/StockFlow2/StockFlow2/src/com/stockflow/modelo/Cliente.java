/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;

/**
 *
 * @author alduc
 */

public class Cliente extends Entidad {
    private String nombre;
    private String apellido;
    private String telefono;
    private String correo;
    private String rfc;
    private String razonSocial;
    private boolean activo;

    public Cliente(String codigo, String nombre, String apellido, String telefono,
                   String correo, String rfc, String razonSocial) {
        super(codigo);
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.rfc = rfc;
        this.razonSocial = razonSocial;
        this.activo = true;
    }

    public String getNombre() { 
        return nombre;
    }
    public String getApellido() {
        return apellido; 
    }
    public String getRfc() { 
        return rfc; 
    }
    public String getRazonSocial() { 
        return razonSocial;
    }
    public String getCorreo() {
        return correo; 
    }

    public boolean esActivo() {
        return activo;
    }

    // Valida si el cliente tiene RFC, razón social y correo para facturar (RN-12 / EX-06)
    public boolean tieneDatosFiscales() {
        return rfc != null && !rfc.isBlank()
                && razonSocial != null && !razonSocial.isBlank()
                && correo != null && !correo.isBlank();
    }

    @Override
    public String mostrarResumen() {
        return nombre + " " + apellido + " (" + identificador + ")";
    }
}
