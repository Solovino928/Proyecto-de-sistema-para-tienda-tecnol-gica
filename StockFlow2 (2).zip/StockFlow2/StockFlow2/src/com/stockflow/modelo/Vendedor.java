/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.modelo;
import java.time.LocalDateTime;

/**
 *
 * @author alduc
 */
// Archivo: com/stockflow/modelo/Vendedor.java


public class Vendedor extends Entidad {
    private String nombre;
    private String apellido;
    private int edad;
    private LocalDateTime fechaModificacion;

    public Vendedor(String id, String nombre, String apellido, int edad) {
        super(id);
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.fechaModificacion = LocalDateTime.now();
    }

    public String getNombre(){ 
        return nombre;
    }
    public String getApellido(){ 
        return apellido;
    }
    public int getEdad(){
        return edad; 
    }
    public LocalDateTime getFechaModificacion(){ 
        return fechaModificacion; 
    }

    public String nombreCompleto() {
        return nombre + " " + apellido;
    }

    public void actualizar(String n, String a, int e) {
        this.nombre = n;
        this.apellido = a;
        this.edad = e;
        this.fechaModificacion = LocalDateTime.now();
    }

    @Override
    public String mostrarResumen() {
        return nombreCompleto() + " (" + edad + " años)";
    }
}
