/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.dao;

/**
 *
 * @author alduc
 */

public class FolioGeneratorDAO {
    private int consecutivo = 0;

    public String generarFolio() {
        consecutivo++;
        return String.format("STKD-2026-%04d", consecutivo);
    }
}