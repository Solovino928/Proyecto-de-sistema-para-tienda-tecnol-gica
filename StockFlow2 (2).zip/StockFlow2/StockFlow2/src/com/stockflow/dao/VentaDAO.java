/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.dao;

import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Venta;
import java.util.ArrayList;

/**
 *
 * @author alduc
 */



public class VentaDAO implements PersistenciaVenta {
    private ArrayList<Venta> ventasRegistradas = new ArrayList<>();
    private FolioGeneratorDAO folioGenerator = new FolioGeneratorDAO();

    @Override
    public boolean registrarVenta(Venta venta) {
        if (venta == null || venta.getDetalles().isEmpty()) {
            return false;
        }

        // 1. Verificación previa del bloque atómico (RNF-03 / EX-03)
        for (DetalleVenta d : venta.getDetalles()) {
            if (!d.getProducto().hayStock(d.getCantidad())) {
                return false; // Cancela toda la operación sin alterar existencias
            }
        }

        // 2. Descuento de stock y asignación de folio único consecutivo (RF-03.2 y RF-03.3)
        for (DetalleVenta d : venta.getDetalles()) {
            d.getProducto().descontarStock(d.getCantidad());
        }

        String nuevoFolio = folioGenerator.generarFolio();
        venta.setFolio(nuevoFolio);
        ventasRegistradas.add(venta);
        return true;
    }

    public ArrayList<Venta> getVentasRegistradas() {
        return ventasRegistradas;
    }
}