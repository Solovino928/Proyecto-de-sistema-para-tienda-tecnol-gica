/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;
import com.stockflow.dao.PersistenciaVenta;
import com.stockflow.dao.VentaDAO;
import com.stockflow.modelo.Cliente;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import com.stockflow.modelo.Vendedor;
import com.stockflow.modelo.Venta;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */




public class VentaService {
    private ArrayList<DetalleVenta> carrito = new ArrayList<>();
    private PersistenciaVenta persistencia = new VentaDAO();
    private CalculadoraImpuestos calculadora = new CalculadoraImpuestos();
    // Vendedor único predeterminado desde la instalación (RN-11 / DBD V2.0)
    private Vendedor vendedorPredeterminado = new Vendedor("1", "Laura", "Mendoza Cruz", 28);

    public ArrayList<DetalleVenta> getCarrito() {
        return carrito;
    }

    public Vendedor obtenerVendedor() {
        return vendedorPredeterminado;
    }

    public boolean validarStock(Producto p, int cantidad) {
        return p != null && cantidad > 0 && p.hayStock(cantidad);
    }

    // Iteración 2: Agrega artículos validando cantidad positiva (RN-01) y stock (RN-02 / EX-01)
    public String agregarAlCarrito(Producto p, int cantidad) {
        if (p == null) return "Seleccione un producto.";
        if (cantidad <= 0) return "La cantidad debe ser mayor a cero (RN-01).";

        DetalleVenta existente = null;
        for (DetalleVenta d : carrito) {
            if (d.getProducto().getIdentificador().equals(p.getIdentificador())) {
                existente = d;
                break;
            }
        }

        int totalSolicitado = cantidad + (existente != null ? existente.getCantidad() : 0);
        if (!validarStock(p, totalSolicitado)) {
            return "EX-01: Stock insuficiente. Disponible: " + p.getStock();
        }

        if (existente != null) {
            existente.actualizarCantidad(totalSolicitado);
        } else {
            carrito.add(new DetalleVenta(p, cantidad));
        }
        return null;
    }

    public void quitarDelCarrito(int fila) {
        if (fila >= 0 && fila < carrito.size()) {
            carrito.remove(fila);
        }
    }

    public void limpiarCarrito() {
        carrito.clear();
    }

    public double obtenerSubtotal() {
        return calculadora.calcularSubtotal(carrito);
    }

    public double obtenerIVA() {
        return calculadora.calcularIVA(obtenerSubtotal());
    }

    public double obtenerTotal() {
        return calculadora.calcularTotal(obtenerSubtotal(), obtenerIVA());
    }

    // Iteración 3: Valida datos fiscales cuando la venta requiere factura (RN-12 / EX-06)
    public String validarFactura(Venta v) {
        if (!v.isRequiereFactura()) return null;
        Cliente c = v.getCliente();
        if (c == null) return "EX-06: Seleccione un cliente para facturar.";
        if (!c.esActivo()) return "EX-06: El cliente está inactivo (RN-09).";
        if (!c.tieneDatosFiscales()) {
            return "EX-06: Complete RFC, razón social y correo del cliente.";
        }
        return null;
    }

    // Iteración 3: Procesa la venta de forma atómica, asigna el folio y limpia el carrito (RF-03.2 y RF-03.3)
    public boolean procesarVenta(Venta venta) {
        if (carrito.isEmpty()) return false;
        boolean exito = persistencia.registrarVenta(venta);
        if (exito) {
            limpiarCarrito();
        }
        return exito;
    }
}