/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.stockflow.controlador;
import com.stockflow.modelo.DetalleVenta;
import java.util.ArrayList;
/**
 *
 * @author adrianzsanchezalducin
 */

public class CalculadoraImpuestos {

    public double calcularSubtotal(ArrayList<DetalleVenta> detalles) {
        double suma = 0;
        for (DetalleVenta d : detalles) {
            suma += d.calcularImporte();
        }
        return suma;
    }

    public double calcularIVA(double subtotal) {
        return subtotal * 0.16;
    }

    public double calcularTotal(double subtotal, double iva) {
        return subtotal + iva;
    }
}
