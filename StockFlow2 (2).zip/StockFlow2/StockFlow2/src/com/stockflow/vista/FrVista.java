package com.stockflow.vista;

import com.stockflow.controlador.CatalogoService;
import com.stockflow.controlador.VentaService;
import com.stockflow.modelo.DetalleVenta;
import com.stockflow.modelo.Producto;
import com.stockflow.modelo.Venta;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

public class FrVista extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrVista.class.getName());
    
    private CatalogoService catalogoService = new CatalogoService();
    private VentaService ventaService = new VentaService();
    
    private DefaultTableModel modeloCatalogo;
    private DefaultTableModel modeloVenta;
    private DecimalFormat formatoMoneda = new DecimalFormat("$#,##0.00");

    public FrVista() {
        initComponents();
        configurarTablasYControles();
        cargarTablaCatalogo(catalogoService.listar());
    }

    private void configurarTablasYControles() {
        setLocationRelativeTo(null);
        
        // Bloqueado al inicio porque la lista está vacía (RN-04)
        btn_Confirmar.setEnabled(false);
        
        // Spinner configurado para enteros mayores a cero (RN-01)
        Spi_cantidad.setModel(new SpinnerNumberModel(1, 1, 999, 1));

        // Tabla del catálogo (MOD-01)
        modeloCatalogo = new DefaultTableModel(
                new Object[]{"Código", "Producto", "Categoría", "Precio (MXN)", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tbl_productos.setModel(modeloCatalogo);

        // Tabla de la lista de compra (MOD-02)
        modeloVenta = new DefaultTableModel(
                new Object[]{"Código", "Producto", "Cant.", "P. Unitario", "Importe"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tbl_lista.setModel(modeloVenta);

        lbl_Subtotal.setText("$0.00");
        lbl_IVA.setText("$0.00");
        lbl_Total.setText("$0.00 MXN");

        // Búsqueda dinámica en tiempo real (RF-01.2)
        txtBusqueda.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrarCatalogo(); }
            public void removeUpdate(DocumentEvent e) { filtrarCatalogo(); }
            public void changedUpdate(DocumentEvent e) { filtrarCatalogo(); }
        });
    }

    private void filtrarCatalogo() {
        if (CBcategoria.getSelectedItem() == null) return;
        String texto = txtBusqueda.getText();
        String categoria = CBcategoria.getSelectedItem().toString();
        cargarTablaCatalogo(catalogoService.buscar(texto, categoria));
    }

    private void cargarTablaCatalogo(ArrayList<Producto> lista) {
        modeloCatalogo.setRowCount(0);
        for (Producto p : lista) {
            modeloCatalogo.addRow(new Object[]{
                p.getIdentificador(),
                p.getNombre(),
                p.getCategoria().getNombre(),
                formatoMoneda.format(p.getPrecio()),
                p.getStock()
            });
        }
    }

    private void actualizarTablaVenta() {
        modeloVenta.setRowCount(0);
        for (DetalleVenta d : ventaService.getCarrito()) {
            modeloVenta.addRow(new Object[]{
                d.getProducto().getIdentificador(),
                d.getProducto().getNombre(),
                d.getCantidad(),
                formatoMoneda.format(d.getPrecioUnitario()),
                formatoMoneda.format(d.calcularImporte())
            });
        }

        lbl_Subtotal.setText(formatoMoneda.format(ventaService.obtenerSubtotal()));
        lbl_IVA.setText(formatoMoneda.format(ventaService.obtenerIVA()));
        lbl_Total.setText(formatoMoneda.format(ventaService.obtenerTotal()) + " MXN");

        // Habilita el botón de confirmar solo si hay al menos una partida (RN-04 / RF-03.1)
        btn_Confirmar.setEnabled(!ventaService.getCarrito().isEmpty());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_productos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        CBcategoria = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Spi_cantidad = new javax.swing.JSpinner();
        btn_Agregarventa = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        btn_Quitar = new javax.swing.JButton();
        btn_Limpiar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_lista = new javax.swing.JTable();
        btn_Confirmar = new javax.swing.JToggleButton();
        jLabel7 = new javax.swing.JLabel();
        lbl_Subtotal = new javax.swing.JLabel();
        lbl_IVA = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lbl_Total = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("StockFlow - Mostrador de ventas");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(28, 28, 28))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tbl_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Producto", "Categoria", "Precio (MXN)", "Stock"
            }
        ));
        jScrollPane1.setViewportView(tbl_productos);

        jLabel1.setText("Buscar");

        txtBusqueda.addActionListener(this::txtBusquedaActionPerformed);

        CBcategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todas", "Perifericos", "Almacenamiento", "Accesorios y conectividad" }));
        CBcategoria.addActionListener(this::CBcategoriaActionPerformed);

        jLabel3.setText("Cantidad");

        btn_Agregarventa.setText("Agregar a la venta");
        btn_Agregarventa.addActionListener(this::btn_AgregarventaActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(jLabel1)
                .addGap(37, 37, 37)
                .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(CBcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabel2)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel3)
                        .addGap(69, 69, 69)
                        .addComponent(Spi_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addComponent(btn_Agregarventa))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CBcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Spi_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Agregarventa))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(44, 44, 44))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_Quitar.setText("Quitar Articulo Seleccionado");
        btn_Quitar.addActionListener(this::btn_QuitarActionPerformed);

        btn_Limpiar.setText("Limpiar Lista");
        btn_Limpiar.addActionListener(this::btn_LimpiarActionPerformed);

        tbl_lista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "codigo", "Producto", "Cant. ", "P. Unitario", "Importe"
            }
        ));
        jScrollPane2.setViewportView(tbl_lista);

        btn_Confirmar.setText("Confirmar Venta");
        btn_Confirmar.addActionListener(this::btn_ConfirmarActionPerformed);

        jLabel7.setText("Subtotal");

        jLabel8.setText("IVA 16%");

        jLabel9.setText("Total");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btn_Quitar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                        .addComponent(btn_Limpiar)))
                .addGap(42, 42, 42))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_Confirmar)
                .addGap(51, 51, 51))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel7)
                        .addComponent(jLabel8))
                    .addComponent(jLabel9))
                .addGap(113, 113, 113)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_IVA, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(lbl_Subtotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_Total, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Quitar)
                    .addComponent(btn_Limpiar))
                .addGap(40, 40, 40)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_Subtotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_IVA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(lbl_Total, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(btn_Confirmar)
                .addContainerGap())
        );

        jLabel5.setText("Catalogo de productos");

        jLabel6.setText("Lista de la compra y registro");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(353, 353, 353))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>                        

    private void txtBusquedaActionPerformed(java.awt.event.ActionEvent evt) {                                            
        filtrarCatalogo();
    }                                           

    private void CBcategoriaActionPerformed(java.awt.event.ActionEvent evt) {                                            
        filtrarCatalogo();
    }                                           

    private void btn_QuitarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        int fila = tbl_lista.getSelectedRow();
        if (fila >= 0) {
            ventaService.quitarDelCarrito(fila);
            actualizarTablaVenta();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un artículo de la lista para quitarlo.");
        }
    }                                          

    private void btn_LimpiarActionPerformed(java.awt.event.ActionEvent evt) {                                            
        ventaService.limpiarCarrito();
        actualizarTablaVenta();
    }                                           

    private void btn_AgregarventaActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        int fila = tbl_productos.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto del catálogo.");
            return;
        }
        String codigo = modeloCatalogo.getValueAt(fila, 0).toString();
        Producto prod = catalogoService.buscarCodigo(codigo);
        int cantidad = (Integer) Spi_cantidad.getValue();

        String error = ventaService.agregarAlCarrito(prod, cantidad);
        if (error != null) {
            JOptionPane.showMessageDialog(this, error, "Alerta de Stock (EX-01)", JOptionPane.WARNING_MESSAGE);
        } else {
            Spi_cantidad.setValue(1);
            actualizarTablaVenta();
        }
    }                                                

    private void btn_ConfirmarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        if (ventaService.getCarrito().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La venta debe tener al menos una partida (RN-04).");
            return;
        }

        double subtotal = ventaService.obtenerSubtotal();
        double iva = ventaService.obtenerIVA();
        double total = ventaService.obtenerTotal();

        // Construir objeto Venta con el vendedor registrado y cliente opcional "Público en general" (RF-03.1 / RN-07)
        Venta nuevaVenta = new Venta(
                "PENDIENTE",
                ventaService.obtenerVendedor(),
                null, // Público en general
                false, // Sin factura en venta rápida de mostrador
                ventaService.getCarrito(),
                subtotal,
                iva,
                total
        );

        String errorFactura = ventaService.validarFactura(nuevaVenta);
        if (errorFactura != null) {
            JOptionPane.showMessageDialog(this, errorFactura, "Validación de Factura (EX-06)", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 1. Armar ventana modal de confirmación (SCR-02 / RF-03.1)
        String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        StringBuilder resumen = new StringBuilder();
        resumen.append("=== CONFIRMAR REGISTRO DE VENTA - STOCKFLOW ===\n");
        resumen.append("Fecha y Hora: ").append(fechaHora).append("\n");
        resumen.append("Vendedor: ").append(nuevaVenta.getVendedor().nombreCompleto()).append("\n");
        resumen.append("Cliente: Público en general\n");
        resumen.append("Factura: No\n");
        resumen.append("--------------------------------------------------\n");

        for (DetalleVenta d : nuevaVenta.getDetalles()) {
            resumen.append(d.getCantidad()).append("x ")
                   .append(d.getProducto().getNombre())
                   .append(" (").append(d.getProducto().getIdentificador()).append(")")
                   .append("  ->  ").append(formatoMoneda.format(d.calcularImporte())).append("\n");
        }

        resumen.append("--------------------------------------------------\n");
        resumen.append("Subtotal: ").append(formatoMoneda.format(subtotal)).append(" MXN\n");
        resumen.append("IVA (16%): ").append(formatoMoneda.format(iva)).append(" MXN\n");
        resumen.append("TOTAL A COBRAR: ").append(formatoMoneda.format(total)).append(" MXN\n\n");
        resumen.append("¿Desea confirmar y registrar la venta?");

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                resumen.toString(),
                "Confirmar Registro de Venta (SCR-02)",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        // 2. Ejecutar registro atómico, descontar stock y emitir folio único (RF-03.2 y RF-03.3 / SCR-03)
        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean exito = ventaService.procesarVenta(nuevaVenta);
            if (exito) {
                filtrarCatalogo();
                actualizarTablaVenta();

                JOptionPane.showMessageDialog(
                        this,
                        "¡VENTA REGISTRADA CON ÉXITO!\n\n"
                        + "FOLIO ASIGNADO: " + nuevaVenta.getIdentificador() + "\n"
                        + "Vendedor: " + nuevaVenta.getVendedor().nombreCompleto() + "\n"
                        + "Total cobrado: " + formatoMoneda.format(total) + " MXN\n\n"
                        + "El inventario ha sido actualizado y la pantalla está lista para la siguiente venta.",
                        "Venta Exitosa - Folio " + nuevaVenta.getIdentificador() + " (SCR-03)",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "EX-03: Error al guardar la venta. No se restaron existencias.",
                        "Error de Transacción (EX-03)",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }                                             

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new FrameVista().setVisible(true));
    }

    // Variables declaration - do not modify                     
    private javax.swing.JComboBox<String> CBcategoria;
    private javax.swing.JSpinner Spi_cantidad;
    private javax.swing.JButton btn_Agregarventa;
    private javax.swing.JToggleButton btn_Confirmar;
    private javax.swing.JButton btn_Limpiar;
    private javax.swing.JButton btn_Quitar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbl_IVA;
    private javax.swing.JLabel lbl_Subtotal;
    private javax.swing.JLabel lbl_Total;
    private javax.swing.JTable tbl_lista;
    private javax.swing.JTable tbl_productos;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration                   
}